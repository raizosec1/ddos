# MIRAI-X: Advanced Multi-Vector Attack Platform

## Overview

MIRAI-X is a powerful, next-generation attack platform designed for comprehensive network stress testing and security research. It combines multiple attack vectors in a unified, intelligent orchestration system that adapts to target responses in real-time.

## 🚀 Features

### Multi-Vector Attack Capabilities
- **Layer 7 (HTTP)**: Advanced HTTP flood attacks with Cloudflare bypass
- **Layer 4 (Network)**: UDP, TCP SYN, ICMP, and ACK flood attacks
- **Amplification Attacks**: DNS, NTP, SSDP, Memcached, and SNMP amplification
- **Botnet Coordination**: Distributed attack coordination across multiple nodes
- **Multi-Vector Orchestration**: Simultaneous execution of multiple attack types

### Advanced Evasion & Stealth
- **Browser Fingerprint Randomization**: Realistic user agent and header generation
- **IP Spoofing**: Source IP randomization for attack anonymity
- **Human-like Behavior**: Variable timing and request patterns
- **Challenge Bypass**: Advanced Cloudflare and CAPTCHA solving
- **Proxy Management**: Rotating proxy support with health checking

### Intelligent Monitoring & Adaptation
- **Real-time Metrics**: System resource and network performance monitoring
- **Adaptive Scaling**: Dynamic adjustment based on target response
- **Attack Effectiveness Analysis**: Real-time assessment of attack impact
- **Comprehensive Reporting**: Detailed attack reports and statistics

## 📦 Installation

1. **Clone the repository:**
```bash
git clone https://github.com/your-repo/mirai-x.git
cd mirai-x
```

2. **Install dependencies:**
```bash
pip install -r requirements.txt
```

3. **Required packages:**
- `asyncio`
- `aiohttp`
- `psutil`
- `undetected-chromedriver`
- `selenium`
- `psutil`

## 🎯 Usage

### Basic Layer 7 Attack
```bash
python main.py --target https://example.com --attack-type l7 --method GET --rate 1000 --workers 10
```

### Advanced Multi-Vector Attack
```bash
python main.py --target 192.168.1.1 --attack-type multi --intensity extreme --adaptive-mode --duration 300
```

### Layer 4 Flood Attack
```bash
python main.py --target 10.0.0.5 --attack-type l4 --l4-method udp --port 80 --threads 100 --packet-size 4096
```

### Amplification Attack
```bash
python main.py --target 8.8.8.8 --attack-type amp --amp-method dns --reflection-ratio 50
```

### Botnet Coordination
```bash
# Server mode
python main.py --attack-type botnet --coordination-server --botnet-file bots.txt --listen-port 6667

# Client mode (on bot nodes)
python main.py --attack-type botnet --botnet-file bots.txt --botnet-key encryption_key
```

## ⚙️ Configuration

### Command Line Options

#### Global Options
- `--target`: Target URL/IP (required)
- `--attack-type`: Attack type (`l7`, `l4`, `amp`, `botnet`, `multi`)
- `--duration`: Attack duration in seconds (0 for indefinite)
- `--stealth-mode`: Enable maximum stealth features
- `--debug`: Enable debug output

#### Layer 7 Options
- `--method`: HTTP method (GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS)
- `--rate`: Requests per second per worker
- `--workers`: Number of concurrent workers
- `--post-data`: JSON POST data
- `--headers-file`: Custom headers file
- `--challenge-solver-mode`: Challenge solving mode (`headless_browser`, `js_engine_parse`, `advanced_stealth`)

#### Layer 4 Options
- `--l4-method`: Attack method (`udp`, `tcp`, `syn`, `ack`, `icmp`)
- `--port`: Target port
- `--packet-size`: Packet size in bytes
- `--threads`: Number of attack threads

#### Amplification Options
- `--amp-method`: Amplification method (`dns`, `ntp`, `ssdp`, `memcached`, `chargen`, `snmp`)
- `--amplifier-file`: File containing amplifier list
- `--reflection-ratio`: Expected amplification ratio

#### Botnet Options
- `--botnet-file`: Botnet node list file
- `--botnet-key`: Encryption key for communication
- `--coordination-server`: Run as coordination server
- `--listen-port`: Port for coordination server

#### Multi-Vector Options
- `--vector-intensity`: Intensity level (`low`, `medium`, `high`, `extreme`)
- `--adaptive-mode`: Enable adaptive attack scaling

### Configuration File

Create a `config.json` file to set default parameters:

```json
{
  "proxy_file": "proxies.txt",
  "user_agent_file": "user_agents.txt",
  "custom_headers_file": "headers.json",
  "proxy_check_interval": 300,
  "headless_browser_path": "/usr/bin/chromium-browser",
  "js_engine_timeout": 10,
  "connection_timeout": 5,
  "read_timeout": 10,
  "max_redirects": 5,
  "max_retries": 3,
  "retry_delay": 2
}
```

## 🏗️ Architecture

### Core Modules

1. **main.py**: Central command and control system
2. **attack_orchestrator.py**: Layer 7 attack coordination
3. **layer4_attacks.py**: Layer 4 flood attack management
4. **amplification_attacks.py**: Amplification attack coordination
5. **botnet_coordinator.py**: Distributed botnet management
6. **multi_vector_orchestrator.py**: Multi-vector attack orchestration
7. **monitoring.py**: Real-time monitoring and reporting
8. **evasion_module.py**: Challenge bypass and stealth features
9. **proxy_manager.py**: Proxy rotation and health checking
10. **request_builder.py**: HTTP request construction
11. **utils.py**: Utility functions and helpers

### Attack Flow

1. **Initialization**: Parse arguments and load configuration
2. **Target Assessment**: Analyze target vulnerabilities (if adaptive mode)
3. **Vector Selection**: Choose appropriate attack vectors
4. **Resource Allocation**: Distribute resources across vectors
5. **Execution**: Launch attacks with real-time monitoring
6. **Adaptation**: Adjust attack parameters based on effectiveness
7. **Reporting**: Generate comprehensive attack reports

## 🔒 Security Considerations

⚠️ **WARNING**: This tool is designed for authorized security testing only. Unauthorized use may violate laws and ethical guidelines.

- Always obtain explicit permission before testing
- Use only against systems you own or have written authorization to test
- Be aware of local laws regarding network security testing
- Consider the potential impact on third-party services

## 📊 Monitoring & Reporting

### Real-time Metrics
- System resource usage (CPU, memory, disk)
- Network bandwidth consumption
- Attack success rates and effectiveness
- Target response times and availability

### Attack Reports
- Detailed attack statistics and metrics
- Vector-specific performance data
- System resource utilization
- Attack effectiveness analysis

### Example Report Output
```json
{
  "attack_id": "atk_1699123456_abc12345",
  "attack_type": "multi_vector",
  "target": "https://example.com",
  "duration": 127.5,
  "vector_results": {
    "l7": {"status": "success", "workers": 25},
    "l4": {"status": "success", "method": "udp", "threads": 50},
    "amplification": {"status": "success", "method": "dns"}
  },
  "effectiveness_metrics": {
    "l7": 0.8,
    "l4": 0.7,
    "amplification": 0.6
  }
}
```

## 🚨 Troubleshooting

### Common Issues

1. **Permission Errors**: Ensure proper permissions for raw socket operations
2. **Proxy Issues**: Verify proxy format and availability
3. **Browser Issues**: Check Chrome/Chromium installation for evasion features
4. **Memory Usage**: Monitor system resources during high-intensity attacks

### Debug Mode

Enable debug mode for detailed error information:
```bash
python main.py --debug [other-options]
```

## 🔄 Updates & Contributions

To contribute to MIRAI-X:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is for educational and research purposes only. Users are responsible for compliance with applicable laws and regulations.

## ⚠️ Disclaimer

This tool is provided "as is" for educational and research purposes. The authors are not responsible for any misuse or damage caused by this software. Always ensure you have proper authorization before conducting any security testing.
