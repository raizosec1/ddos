"""
MIRAI-X: Advanced Multi-Vector Attack Platform

A comprehensive attack toolkit for security research and penetration testing.
This package provides multiple attack vectors including Layer 7, Layer 4,
amplification attacks, botnet coordination, and multi-vector orchestration.
"""

__version__ = "2.0.0"
__author__ = "MIRAI-X Development Team"
__description__ = "Advanced Multi-Vector Attack Platform"

# Core attack managers
from .attack_orchestrator import AttackOrchestrator
from .layer4_attacks import Layer4AttackManager
from .amplification_attacks import AmplificationAttackManager
from .botnet_coordinator import BotnetCoordinator
from .multi_vector_orchestrator import MultiVectorOrchestrator

# Supporting modules
from .monitoring import AttackMonitor
from .evasion_module import EvasionModule
from .proxy_manager import ProxyManager
from .request_builder import RequestBuilder

# Utilities
from .utils import (
    log_attack_metrics,
    generate_random_user_agent,
    generate_random_http_headers,
    generate_random_ip_spoof,
    calculate_attack_efficiency,
    generate_attack_id,
    obfuscate_payload,
    calculate_optimal_thread_count,
    generate_fingerprint_mask,
    calculate_packet_timing,
    validate_target,
    generate_attack_report,
    calculate_resource_usage,
    generate_stealth_headers,
    create_attack_signature,
    estimate_attack_impact
)

# Configuration
from .config import load_config

# Main command interface
from .main import AttackCommander

__all__ = [
    # Core classes
    "AttackOrchestrator",
    "Layer4AttackManager",
    "AmplificationAttackManager",
    "BotnetCoordinator",
    "MultiVectorOrchestrator",
    "AttackMonitor",
    "EvasionModule",
    "ProxyManager",
    "RequestBuilder",
    "AttackCommander",

    # Utility functions
    "log_attack_metrics",
    "generate_random_user_agent",
    "generate_random_http_headers",
    "generate_random_ip_spoof",
    "calculate_attack_efficiency",
    "generate_attack_id",
    "obfuscate_payload",
    "calculate_optimal_thread_count",
    "generate_fingerprint_mask",
    "calculate_packet_timing",
    "validate_target",
    "generate_attack_report",
    "calculate_resource_usage",
    "generate_stealth_headers",
    "create_attack_signature",
    "estimate_attack_impact",

    # Configuration
    "load_config",

    # Metadata
    "__version__",
    "__author__",
    "__description__"
]