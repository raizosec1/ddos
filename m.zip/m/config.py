import json
from typing import Dict, Any

DEFAULT_CONFIG_FILE = "config.json"

def load_config(filepath: str = DEFAULT_CONFIG_FILE) -> Dict[str, Any]:
    """
    Loads configuration from a JSON file.
    Provides default values if the file or keys are missing.
    """
    default_config = {
        "target_url": "https://example.com/",
        "method": "GET",
        "rate_per_worker": 100,
        "num_workers": 10,
        "attack_duration_seconds": 0,
        "proxy_file": None,
        "proxy_check_interval": 300,
        "user_agent_file": "user_agents.txt",
        "custom_headers_file": "headers.json",
        "post_data_templates_file": "post_data_templates.json",
        "challenge_solver_mode": "headless_browser",
        "headless_browser_path": "/usr/bin/chromium-browser",
        "js_engine_timeout": 10,
        "connection_timeout": 5,
        "read_timeout": 10,
        "max_redirects": 5,
        "max_retries": 3,
        "retry_delay": 2
    }
    try:
        with open(filepath, 'r') as f:
            user_config = json.load(f)
        default_config.update(user_config)
    except FileNotFoundError:
        print(f"Config file '{filepath}' not found. Using default configuration.")
    except json.JSONDecodeError:
        print(f"Error decoding JSON from '{filepath}'. Using default configuration.")
    return default_config

if __name__ == "__main__":
    current_config = load_config()
    print("Loaded Configuration:")
    for key, value in current_config.items():
        print(f"  {key}: {value}")
