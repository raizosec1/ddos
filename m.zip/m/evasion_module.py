import asyncio
import random
from typing import Dict, Any, Tuple
import undetected_chromedriver as uc
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import re
import execjs

class EvasionModule:
    """
    Manages all Cloudflare bypass techniques, including JS challenges and CAPTCHA solvers.
    """
    def __init__(self, challenge_solver_mode: str = "headless_browser",
                 headless_browser_path: str = None,
                 js_engine_timeout: int = 10):
        self.challenge_solver_mode = challenge_solver_mode
        self.headless_browser_path = headless_browser_path
        self.js_engine_timeout = js_engine_timeout
        self.active_drivers: Dict[str, Any] = {}

    async def _solve_with_headless_browser(self, target_url: str, proxy_addr: str) -> Tuple[Dict[str, str], str | None]:
        """
        Uses a headless browser (undetected_chromedriver) to solve Cloudflare JS challenges.
        Returns cookies and potentially a cf_clearance token.
        """
        print(f"Attempting to solve challenge for {target_url} via headless browser with proxy {proxy_addr}...")
        try:
            options = ChromeOptions()
            options.add_argument("--headless=new")
            options.add_argument("--disable-gpu")
            options.add_argument("--no-sandbox")
            options.add_argument("--disable-dev-shm-usage")
            options.add_argument(f"--proxy-server={proxy_addr}")
            # The user_agents for EvasionModule are not directly available here,
            # this would need to be passed from RequestBuilder or config.
            # For now, using a placeholder.
            options.add_argument(f"user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.88 Safari/537.36")


            driver = uc.Chrome(options=options, executable_path=self.headless_browser_path)
            self.active_drivers[proxy_addr] = driver

            driver.get(target_url)

            WebDriverWait(driver, 30).until(
                lambda d: "Just a moment..." not in d.title and "DDoS protection by Cloudflare" not in d.page_source
                and "Please wait while we verify your browser" not in d.page_source
            )

            cookies = {cookie['name']: cookie['value'] for cookie in driver.get_cookies()}
            cf_clearance = cookies.get('cf_clearance')

            print(f"Challenge solved for {target_url}. CF_Clearance: {cf_clearance}")
            return cookies, cf_clearance

        except Exception as e:
            print(f"Error solving challenge with headless browser for {target_url} via {proxy_addr}: {e}")
            return {}, None
        finally:
            if proxy_addr in self.active_drivers:
                self.active_drivers[proxy_addr].quit()
                del self.active_drivers[proxy_addr]

    async def _solve_with_js_engine(self, page_source: str) -> Dict[str, str]:
        """
        Parses the JavaScript from the Cloudflare challenge page and executes it
        in a sandboxed JS engine to get the solution.
        Highly complex, requires reverse-engineering Cloudflare's JS.
        """
        print("Attempting to solve challenge via JS engine (advanced, requires reverse-engineering)...")
        js_match = re.search(r'(var s,t,o,l,h,a,r,i,m,f,e,u,D,C=(.*?)</script>)', page_source, re.DOTALL)
        if not js_match:
            return {}

        js_code = js_match.group(1)

        try:
            ctx = execjs.compile(js_code)
            
            print("Simulating JS execution for challenge resolution...")
            simulated_cf_clearance = "simulated_cf_clearance_token_" + str(random.randint(1000, 9999))
            return {"cf_clearance": simulated_cf_clearance}
        except Exception as e:
            print(f"Error executing Cloudflare JS challenge in engine: {e}")
            return {}

    async def bypass_cloudflare_challenge(self, target_url: str, proxy_addr: str = None,
                                        initial_response_html: str = None) -> Tuple[Dict[str, str], str | None]:
        """
        Attempts to bypass Cloudflare challenges.
        Returns extracted cookies and potentially a cf_clearance token.
        """
        if self.challenge_solver_mode == "headless_browser":
            return await self._solve_with_headless_browser(target_url, proxy_addr)
        elif self.challenge_solver_mode == "js_engine_parse" and initial_response_html:
            cookies = await self._solve_with_js_engine(initial_response_html)
            return cookies, cookies.get('cf_clearance')
        else:
            print("No suitable challenge solver mode or initial HTML provided.")
            return {}, None

    async def handle_response_for_challenge(self, response_text: str, current_url: str, proxy_addr: str = None) -> Tuple[Dict[str, str], str | None]:
        """
        Analyzes a response to determine if a Cloudflare challenge is present
        and attempts to solve it.
        """
        if "Just a moment..." in response_text or \
           "DDoS protection by Cloudflare" in response_text or \
           "Please wait while we verify your browser" in response_text:
            print(f"Cloudflare challenge detected for {current_url}. Attempting bypass...")
            return await self.bypass_cloudflare_challenge(current_url, proxy_addr, response_text)
        return {}, None
