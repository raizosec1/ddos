import asyncio
import time
import psutil
import socket
import threading
import json
from typing import Dict, Any, Optional, List
from datetime import datetime
import os

class AttackMonitor:
    """
    Advanced attack monitoring and reporting system.
    """

    def __init__(self):
        self.monitoring_active = False
        self.attack_start_time = 0.0
        self.monitoring_data = {}
        self.system_metrics = []
        self.network_metrics = []
        self.attack_metrics = {}
        self.monitoring_thread = None
        self.lock = threading.Lock()

    async def start_monitoring(self, attack_id: str, target: str):
        """Start monitoring an attack."""
        print(f"📊 Starting attack monitoring for {attack_id}")

        self.monitoring_active = True
        self.attack_start_time = time.time()
        self.monitoring_data = {
            'attack_id': attack_id,
            'target': target,
            'start_time': datetime.now().isoformat(),
            'system_metrics': [],
            'network_metrics': [],
            'attack_events': [],
            'peak_metrics': {}
        }

        # Start monitoring thread
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitoring_thread.start()

        return attack_id

    async def stop_monitoring(self, attack_id: str) -> Dict[str, Any]:
        """Stop monitoring and return collected data."""
        print(f"📊 Stopping attack monitoring for {attack_id}")

        self.monitoring_active = False

        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=5.0)

        # Calculate summary statistics
        summary = self._calculate_summary_metrics()

        return {
            'monitoring_data': self.monitoring_data,
            'summary': summary,
            'duration': time.time() - self.attack_start_time
        }

    def _monitoring_loop(self):
        """Main monitoring loop."""
        while self.monitoring_active:
            try:
                # Collect system metrics
                system_data = self._collect_system_metrics()

                # Collect network metrics
                network_data = self._collect_network_metrics()

                # Store metrics
                with self.lock:
                    self.system_metrics.append(system_data)
                    self.network_metrics.append(network_data)
                    self.monitoring_data['system_metrics'].append(system_data)
                    self.monitoring_data['network_metrics'].append(network_data)

                # Keep only last 1000 data points to prevent memory issues
                if len(self.system_metrics) > 1000:
                    self.system_metrics = self.system_metrics[-1000:]
                    self.network_metrics = self.network_metrics[-1000:]

                time.sleep(1.0)  # Monitor every second

            except Exception as e:
                print(f"Monitoring error: {e}")
                time.sleep(1.0)

    def _collect_system_metrics(self) -> Dict[str, Any]:
        """Collect system performance metrics."""
        try:
            cpu_percent = psutil.cpu_percent(interval=None)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            load_avg = psutil.getloadavg() if hasattr(psutil, 'getloadavg') else (0, 0, 0)

            return {
                'timestamp': time.time(),
                'cpu_percent': cpu_percent,
                'memory_percent': memory.percent,
                'memory_used_gb': memory.used / (1024**3),
                'disk_percent': disk.percent,
                'load_average': load_avg[0] if load_avg else 0,
                'process_count': len(psutil.pids())
            }
        except Exception as e:
            return {
                'timestamp': time.time(),
                'error': str(e)
            }

    def _collect_network_metrics(self) -> Dict[str, Any]:
        """Collect network performance metrics."""
        try:
            net_io = psutil.net_io_counters()
            net_ifaces = psutil.net_if_addrs()

            # Get network interface stats
            iface_stats = {}
            for iface_name, iface_addrs in net_ifaces.items():
                try:
                    iface_io = psutil.net_if_stats().get(iface_name, {})
                    iface_stats[iface_name] = {
                        'bytes_sent': net_io.bytes_sent,
                        'bytes_recv': net_io.bytes_recv,
                        'packets_sent': net_io.packets_sent,
                        'packets_recv': net_io.packets_recv,
                        'speed': iface_io.get('speed', 0) if iface_io else 0
                    }
                except:
                    continue

            return {
                'timestamp': time.time(),
                'bytes_sent_per_sec': net_io.bytes_sent,
                'bytes_recv_per_sec': net_io.bytes_recv,
                'packets_sent_per_sec': net_io.packets_sent,
                'packets_recv_per_sec': net_io.packets_recv,
                'interface_stats': iface_stats,
                'active_connections': len(psutil.net_connections())
            }
        except Exception as e:
            return {
                'timestamp': time.time(),
                'error': str(e)
            }

    def add_attack_event(self, event_type: str, details: Dict[str, Any]):
        """Add an attack event to the monitoring log."""
        event = {
            'timestamp': time.time(),
            'event_type': event_type,
            'details': details,
            'relative_time': time.time() - self.attack_start_time
        }

        with self.lock:
            self.monitoring_data['attack_events'].append(event)

    def update_attack_metrics(self, metrics: Dict[str, Any]):
        """Update current attack metrics."""
        with self.lock:
            self.attack_metrics.update(metrics)
            self.monitoring_data['current_metrics'] = metrics.copy()

    def _calculate_summary_metrics(self) -> Dict[str, Any]:
        """Calculate summary statistics from collected data."""
        if not self.system_metrics or not self.network_metrics:
            return {}

        try:
            # System metrics summary
            cpu_values = [m.get('cpu_percent', 0) for m in self.system_metrics if 'cpu_percent' in m]
            memory_values = [m.get('memory_percent', 0) for m in self.system_metrics if 'memory_percent' in m]

            # Network metrics summary
            net_values = [(m.get('bytes_sent_per_sec', 0), m.get('bytes_recv_per_sec', 0))
                         for m in self.network_metrics if 'bytes_sent_per_sec' in m]

            bytes_sent_total = sum(sent for sent, recv in net_values)
            bytes_recv_total = sum(recv for sent, recv in net_values)

            summary = {
                'duration': time.time() - self.attack_start_time,
                'system_summary': {
                    'avg_cpu_percent': sum(cpu_values) / len(cpu_values) if cpu_values else 0,
                    'max_cpu_percent': max(cpu_values) if cpu_values else 0,
                    'avg_memory_percent': sum(memory_values) / len(memory_values) if memory_values else 0,
                    'max_memory_percent': max(memory_values) if memory_values else 0,
                },
                'network_summary': {
                    'total_bytes_sent': bytes_sent_total,
                    'total_bytes_recv': bytes_recv_total,
                    'avg_send_rate_mbps': (bytes_sent_total * 8) / (1024*1024) / max(summary['duration'], 1),
                    'avg_recv_rate_mbps': (bytes_recv_total * 8) / (1024*1024) / max(summary['duration'], 1),
                },
                'attack_events_count': len(self.monitoring_data.get('attack_events', [])),
                'samples_collected': len(self.system_metrics)
            }

            # Update peak metrics
            self.monitoring_data['peak_metrics'] = {
                'peak_cpu': summary['system_summary']['max_cpu_percent'],
                'peak_memory': summary['system_summary']['max_memory_percent'],
                'peak_send_rate': summary['network_summary']['avg_send_rate_mbps'],
            }

            return summary

        except Exception as e:
            return {'error': str(e)}

    def get_real_time_metrics(self) -> Dict[str, Any]:
        """Get current real-time metrics."""
        current_time = time.time()

        # Get latest system metrics
        latest_system = self.system_metrics[-1] if self.system_metrics else {}
        latest_network = self.network_metrics[-1] if self.network_metrics else {}

        # Calculate rates
        if len(self.system_metrics) >= 2:
            prev_system = self.system_metrics[-2]
            time_diff = latest_system.get('timestamp', current_time) - prev_system.get('timestamp', current_time)

            if time_diff > 0:
                latest_system['cpu_rate'] = (latest_system.get('cpu_percent', 0) - prev_system.get('cpu_percent', 0)) / time_diff

        return {
            'uptime': current_time - self.attack_start_time,
            'system': latest_system,
            'network': latest_network,
            'attack': self.attack_metrics.copy()
        }

    def export_monitoring_data(self, output_file: str = None) -> str:
        """Export monitoring data to JSON file."""
        if not output_file:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = f"attack_monitoring_{timestamp}.json"

        try:
            # Add summary before export
            summary = self._calculate_summary_metrics()
            self.monitoring_data['summary'] = summary

            with open(output_file, 'w') as f:
                json.dump(self.monitoring_data, f, indent=2, default=str)

            print(f"📊 Monitoring data exported to: {output_file}")
            return output_file

        except Exception as e:
            print(f"❌ Error exporting monitoring data: {e}")
            return None

def generate_attack_report(attack_id: str, args, metrics: Dict[str, Any], output_dir: str) -> str:
    """Generate comprehensive attack report."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_file = os.path.join(output_dir, f"attack_report_{attack_id}_{timestamp}.json")

    try:
        report_data = {
            'attack_id': attack_id,
            'timestamp': datetime.now().isoformat(),
            'attack_parameters': vars(args),
            'attack_metrics': metrics,
            'summary': {
                'attack_type': getattr(args, 'attack_type', 'unknown'),
                'target': getattr(args, 'target', 'unknown'),
                'duration': metrics.get('duration', 0),
                'success_rate': 'N/A',  # Would need to be calculated based on attack type
                'total_traffic': metrics.get('bytes_sent', 0) + metrics.get('bytes_amplified', 0)
            }
        }

        with open(report_file, 'w') as f:
            json.dump(report_data, f, indent=2, default=str)

        return report_file

    except Exception as e:
        print(f"❌ Error generating attack report: {e}")
        return None
