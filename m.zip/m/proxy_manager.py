import asyncio
import random
from typing import List, Dict, Tuple, Any
import aiohttp

class ProxyManager:
    """
    Manages a pool of proxies, including loading, health checking, and rotation.
    """
    def __init__(self, proxy_file: str = None, check_interval: int = 300,
                 health_check_url: str = "http://www.google.com/"):
        self.proxy_file = proxy_file
        self.check_interval = check_interval
        self.health_check_url = health_check_url
        self.all_proxies: List[Dict[str, Any]] = []
        self.active_proxies: List[Dict[str, Any]] = []
        self.proxy_lock = asyncio.Lock()
        self.proxy_health_check_task = None

    async def _load_proxies_from_file(self) -> List[Dict[str, Any]]:
        """
        Loads proxies from the specified file.
        Each line in the file is expected to be 'IP:PORT' or 'USER:PASS@IP:PORT'.
        """
        if not self.proxy_file:
            print("No proxy file specified. Running without proxies.")
            return []
        
        loaded_proxies = []
        try:
            with open(self.proxy_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    
                    proxy_info: Dict[str, Any] = {"raw": line}
                    if "@" in line:
                        auth, addr = line.split("@", 1)
                        proxy_info["user"], proxy_info["password"] = auth.split(":", 1)
                        proxy_info["ip"], proxy_info["port"] = addr.split(":", 1)
                    else:
                        proxy_info["ip"], proxy_info["port"] = line.split(":", 1)
                    
                    proxy_info["url"] = f"http://{proxy_info['raw']}"
                    
                    loaded_proxies.append(proxy_info)
            print(f"Loaded {len(loaded_proxies)} proxies from {self.proxy_file}")
            return loaded_proxies
        except FileNotFoundError:
            print(f"Proxy file '{self.proxy_file}' not found.")
            return []
        except Exception as e:
            print(f"Error loading proxies: {e}")
            return []

    async def _check_proxy_health(self, proxy_info: Dict[str, Any]) -> bool:
        """
        Checks if a single proxy is healthy by making a request to a known good URL.
        """
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(self.health_check_url, proxy=proxy_info["url"], timeout=5) as response:
                    return response.status == 200
        except Exception as e:
            return False

    async def _run_health_checks(self):
        """
        Periodically runs health checks on all loaded proxies.
        """
        while True:
            print("Running proxy health checks...")
            healthy_proxies = []
            tasks = [self._check_proxy_health(p) for p in self.all_proxies]
            results = await asyncio.gather(*tasks)

            for i, is_healthy in enumerate(results):
                if is_healthy:
                    healthy_proxies.append(self.all_proxies[i])
            
            async with self.proxy_lock:
                self.active_proxies = healthy_proxies
                print(f"Active healthy proxies: {len(self.active_proxies)}/{len(self.all_proxies)}")
            
            await asyncio.sleep(self.check_interval)

    async def load_and_health_check_proxies(self):
        """Initial load and health check of proxies."""
        self.all_proxies = await self._load_proxies_from_file()
        if self.all_proxies:
            await self._run_health_checks()
            self.proxy_health_check_task = asyncio.create_task(self._run_health_checks())
        else:
            print("No proxies available to health check.")

    async def get_random_proxy(self) -> Dict[str, Any] | None:
        """
        Returns a random active proxy. If no proxies are active, returns None.
        """
        async with self.proxy_lock:
            if not self.active_proxies:
                return None
            return random.choice(self.active_proxies)

    async def remove_bad_proxy(self, proxy_info: Dict[str, Any]):
        """Removes a proxy from the active list if it's found to be bad during an attack."""
        async with self.proxy_lock:
            if proxy_info in self.active_proxies:
                self.active_proxies.remove(proxy_info)
                print(f"Removed bad proxy: {proxy_info['raw']}. Remaining active: {len(self.active_proxies)}")

    def stop(self):
        if self.proxy_health_check_task:
            self.proxy_health_check_task.cancel()
            print("Proxy health check task cancelled.")
