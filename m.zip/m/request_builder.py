import random
import json
import time
from typing import Dict, List, Any, Optional
from urllib.parse import urlparse, urlencode

from .utils import (
    generate_random_user_agent,
    generate_random_http_headers,
    generate_stealth_headers,
    generate_fingerprint_mask,
    calculate_packet_timing,
    obfuscate_payload
)

class RequestBuilder:
    """
    Advanced HTTP request builder with stealth and evasion capabilities.
    Handles dynamic construction of HTTP/HTTPS requests with fingerprint randomization.
    """

    def __init__(self, target_url: str, method: str,
                 user_agent_file: str = "user_agents.txt",
                 custom_headers_file: str = "headers.json",
                 post_data_templates_file: str = "post_data_templates.json",
                 stealth_mode: bool = False):
        self.target_url = target_url
        self.method = method.upper()
        self.stealth_mode = stealth_mode

        # Load user agents
        self.user_agents = self._load_from_file(user_agent_file)

        # Load custom headers and templates
        self.custom_headers_pool = self._load_json_data(custom_headers_file)
        self.post_data_templates = self._load_json_data(post_data_templates_file)

        # Parse base URL
        self.url_base = urlparse(target_url)._replace(query="").geturl()

        # Initialize stealth features
        self.fingerprint_cache = {}
        self.request_timings = []
        self.session_tokens = {}

        # Set defaults if files not found
        if not self.user_agents:
            self.user_agents = ["Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.88 Safari/537.36"]
            print("Warning: User-agent file empty or not found. Using default UA.")

        if not self.custom_headers_pool:
            self.custom_headers_pool = [
                {"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
                 "Accept-Language": "en-US,en;q=0.5",
                 "Connection": "keep-alive"}
            ]
            print("Warning: Custom headers file empty or not found. Using default headers.")

    def _load_from_file(self, filepath: str) -> List[str]:
        """Loads lines from a text file."""
        try:
            with open(filepath, 'r') as f:
                return [line.strip() for line in f if line.strip()]
        except FileNotFoundError:
            return []

    def _load_json_data(self, filepath: str) -> List[Dict[str, Any]]:
        """Loads JSON data from a file, expecting a list of dictionaries."""
        try:
            with open(filepath, 'r') as f:
                data = json.load(f)
                if isinstance(data, list):
                    return data
                else:
                    print(f"Warning: JSON file '{filepath}' did not contain a list. Returning empty list.")
                    return []
        except FileNotFoundError:
            return []
        except json.JSONDecodeError:
            print(f"Warning: Error decoding JSON from '{filepath}'. Returning empty list.")
            return []

    def _generate_session_id(self) -> str:
        """Generate a unique session identifier."""
        import hashlib
        session_data = f"{self.target_url}:{random.randint(1000, 9999)}:{time.time()}"
        return hashlib.md5(session_data.encode()).hexdigest()[:12]

    def _generate_random_query_params(self) -> str:
        """Generates random URL query parameters to evade caching/rate limits."""
        params = {
            "_": random.randint(100000, 999999999),
            "v": random.randint(1, 1000),
            "t": int(time.time())
        }

        # Add stealth parameters in stealth mode
        if self.stealth_mode:
            params.update({
                "utm_source": f"referrer{random.randint(1, 100)}",
                "utm_medium": "organic",
                "session_id": self._generate_session_id()
            })

        return urlencode(params)

    def _get_random_user_agent(self) -> str:
        """Returns a random User-Agent string."""
        if self.stealth_mode and random.random() > 0.7:
            return generate_random_user_agent()
        return random.choice(self.user_agents)

    def _get_random_headers(self, existing_headers: Dict[str, str] = None) -> Dict[str, str]:
        """
        Returns a set of randomized headers, optionally merging with existing ones.
        """
        if self.stealth_mode and random.random() > 0.5:
            headers = generate_stealth_headers()
        else:
            headers = random.choice(self.custom_headers_pool).copy()
            headers["User-Agent"] = self._get_random_user_agent()

        if existing_headers:
            headers.update(existing_headers)

        return headers

    def _get_post_data(self) -> str | bytes:
        """Generates dynamic POST data based on templates with obfuscation."""
        if not self.post_data_templates:
            return ""

        template = random.choice(self.post_data_templates)

        dynamic_data = template.copy()
        for key, value in dynamic_data.items():
            if isinstance(value, str):
                # Replace random string placeholders
                if "{random_string}" in value:
                    random_str = ''.join(random.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=10))
                    dynamic_data[key] = value.replace("{random_string}", random_str)
                # Obfuscate payload in stealth mode
                elif self.stealth_mode and random.random() > 0.7:
                    dynamic_data[key] = obfuscate_payload(value)

        return json.dumps(dynamic_data)

    def _add_timing_delays(self) -> float:
        """Calculate request timing delays for stealth."""
        if not self.stealth_mode:
            return 0.0

        base_delay = 0.1  # Base delay between requests

        # Calculate human-like timing
        delay = calculate_packet_timing(base_delay, stealth_mode=True)

        # Add request to timing history for pattern analysis
        self.request_timings.append(time.time())
        if len(self.request_timings) > 100:
            self.request_timings = self.request_timings[-100:]

        return delay

    def _generate_browser_fingerprint(self) -> Dict[str, Any]:
        """Generate a browser fingerprint for this request."""
        if self.stealth_mode:
            fingerprint = generate_fingerprint_mask()

            # Cache fingerprint for session consistency
            session_id = self._generate_session_id()
            self.fingerprint_cache[session_id] = fingerprint

            return fingerprint

        return {}

    async def build_request(self, cookies: Dict[str, str] = None,
                          cf_clearance: str = None,
                          session_cookies: Dict[str, str] = None) -> Dict[str, Any]:
        """
        Builds a complete HTTP/HTTPS request dictionary ready for sending.
        Includes dynamic headers, query parameters, fingerprints, and POST data.
        """
        url = self.target_url
        headers = self._get_random_headers()
        data = None

        # Generate browser fingerprint for stealth mode
        fingerprint = self._generate_browser_fingerprint()

        if self.method == "GET":
            parsed_url = urlparse(url)
            query_params = self._generate_random_query_params()
            new_query = f"{parsed_url.query}&{query_params}" if parsed_url.query else query_params
            url = parsed_url._replace(query=new_query).geturl()

            # Add stealth headers for GET requests
            if self.stealth_mode:
                headers.update({
                    "Sec-Fetch-Dest": "document",
                    "Sec-Fetch-Mode": "navigate",
                    "Sec-Fetch-Site": "none",
                    "Cache-Control": "max-age=0"
                })

        elif self.method in ["POST", "PUT", "PATCH"]:
            data = self._get_post_data()

            # Set appropriate content type
            if isinstance(data, str):
                headers["Content-Type"] = headers.get("Content-Type", "application/json")
            else:
                headers["Content-Type"] = headers.get("Content-Type", "application/x-www-form-urlencoded")

        # Handle cookies
        all_cookies = {}
        if cookies:
            all_cookies.update(cookies)
        if session_cookies:
            all_cookies.update(session_cookies)

        if all_cookies:
            cookie_header = "; ".join([f"{k}={v}" for k, v in all_cookies.items()])
            headers["Cookie"] = cookie_header

        # Handle Cloudflare clearance token
        if cf_clearance:
            headers["CF_Clearance"] = cf_clearance

        # Add timing delay for stealth
        timing_delay = self._add_timing_delays()

        return {
            "url": url,
            "method": self.method,
            "headers": headers,
            "data": data,
            "cookies": all_cookies,
            "fingerprint": fingerprint,
            "timing_delay": timing_delay,
            "stealth_mode": self.stealth_mode
        }

    def get_request_statistics(self) -> Dict[str, Any]:
        """Get statistics about request building."""
        return {
            "user_agents_count": len(self.user_agents),
            "headers_pool_count": len(self.custom_headers_pool),
            "post_templates_count": len(self.post_data_templates),
            "stealth_mode": self.stealth_mode,
            "cached_fingerprints": len(self.fingerprint_cache),
            "request_timings_count": len(self.request_timings)
        }
